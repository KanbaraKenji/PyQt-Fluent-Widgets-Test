from PySide6.QtWidgets import QWidget, QPushButton, QVBoxLayout

from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QMessageBox, QHBoxLayout
from PySide6.QtCore import Qt


class BaseFormFillingWindow(QWidget):
    def __init__(self, template_name, template_path, main_window):
        super().__init__()
        self.template_name = template_name
        self.template_path = template_path
        self.main_window = main_window
        self.init_ui()

    def init_ui(self):
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # 内容区域
        self.content_layout = QVBoxLayout()
        self.layout.addLayout(self.content_layout)

        # 底部按钮布局
        self.bottom_button_layout = QHBoxLayout()

        # 按钮区域
        self.generate_button = QPushButton("生成表单")
        self.generate_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.generate_button.clicked.connect(self.generate_form)
        self.bottom_button_layout.addWidget(self.generate_button)

        # 打开 Excel 按钮
        self.open_excel_button = QPushButton("打开 Excel")
        self.open_excel_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.open_excel_button.clicked.connect(self.open_excel)
        self.open_excel_button.setEnabled(False)
        self.bottom_button_layout.addWidget(self.open_excel_button)

        # 复制 Excel 按钮
        self.copy_excel_button = QPushButton("复制 Excel")
        self.copy_excel_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.copy_excel_button.clicked.connect(self.copy_excel)
        self.copy_excel_button.setEnabled(False)
        self.bottom_button_layout.addWidget(self.copy_excel_button)

        # 发送邮件按钮
        self.send_email_button = QPushButton("发送邮件")
        self.send_email_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.send_email_button.clicked.connect(self.send_email)
        self.send_email_button.setEnabled(False)
        self.bottom_button_layout.addWidget(self.send_email_button)

        self.layout.addLayout(self.bottom_button_layout)

        # 顶部按钮布局
        self.top_button_layout = QHBoxLayout()

        # 返回按钮
        self.back_button = QPushButton("返回")
        self.back_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.back_button.clicked.connect(self.go_back)
        self.top_button_layout.addWidget(self.back_button)

        # 保存按钮
        self.save_button = QPushButton("保存")
        self.save_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.save_button.clicked.connect(self.save_data)
        self.top_button_layout.addWidget(self.save_button)

        self.layout.addLayout(self.top_button_layout)

        # 初始化生成表单路径
        self.generated_form_path = None

    def go_back(self):
        self.main_window.return_to_selection()

    def save_data(self):
        """保存数据到数据库"""
        if self.validate_required_fields():
            try:
                self.update_database()
                QMessageBox.information(self, "提示", "数据已保存到数据库")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"保存数据时出错: {e}")

    def validate_required_fields(self):
        """验证必填项，需由子类实现"""
        raise NotImplementedError("子类必须实现 validate_required_fields 方法")

    def update_database(self):
        """更新数据库，需由子类实现"""
        raise NotImplementedError("子类必须实现 update_database 方法")

    def generate_form(self):
        """生成表单"""
        if self.validate_required_fields():
            try:
                self.replace_placeholders_and_save()
                QMessageBox.information(self, "提示", "表单已生成")
                self.open_excel_button.setEnabled(True)
                self.copy_excel_button.setEnabled(True)
                self.send_email_button.setEnabled(True)
            except Exception as e:
                QMessageBox.critical(self, "错误", f"生成表单时出错: {e}")

    def replace_placeholders_and_save(self):
        """替换占位符并保存表单，需由子类实现"""
        raise NotImplementedError("子类必须实现 replace_placeholders_and_save 方法")

    def open_excel(self):
        """打开生成的 Excel 文件"""
        if self.generated_form_path:
            import os
            os.startfile(self.generated_form_path)
        else:
            QMessageBox.warning(self, "警告", "未生成 Excel 文件")

    def copy_excel(self):
        """复制 Excel 文件路径到剪贴板"""
        if self.generated_form_path:
            from PySide6.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            clipboard.setText(self.generated_form_path)
            QMessageBox.information(self, "提示", "Excel 文件路径已复制到剪贴板")
        else:
            QMessageBox.warning(self, "警告", "未生成 Excel 文件")

    def get_field_value(self, field_name):
        """获取对应字段的值"""
        # 需要在子类中实现此方法
        raise NotImplementedError("子类必须实现 get_field_value 方法。")

    def send_email(self):
        """发送邮件"""
        from utils.email_templates import send_email
        if hasattr(self, 'generated_form_path') and self.generated_form_path:
            send_email(
                template_name=self.template_name,
                get_field_value=self.get_field_value,
                attachment_path=self.generated_form_path
            )
        else:
            QMessageBox.warning(self, "警告", "没有生成的表单可供发送。")