import os

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QTreeWidget, QHBoxLayout, QPushButton, QTreeWidgetItem, \
    QMessageBox


class FormSelectionWindow(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        self.label = QLabel("请选择一个表单模板：")
        self.label.setStyleSheet("font-size: 16px; font-weight: bold;")
        self.layout.addWidget(self.label)

        # 使用 QTreeWidget 代替 QListWidget
        self.template_tree = QTreeWidget()
        self.template_tree.setHeaderLabels(['模板列表'])
        self.template_tree.setStyleSheet("font-size: 14px;")
        self.load_templates()
        self.layout.addWidget(self.template_tree)

        self.button_layout = QHBoxLayout()

        self.select_button = QPushButton("选择")
        self.select_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.select_button.clicked.connect(self.open_form)
        self.button_layout.addWidget(self.select_button)

        self.refresh_button = QPushButton("刷新")
        self.refresh_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.refresh_button.clicked.connect(self.load_templates)
        self.button_layout.addWidget(self.refresh_button)

        self.layout.addLayout(self.button_layout)
        self.setLayout(self.layout)

    def load_templates(self):
        """加载模板列表
        从 './templates' 文件夹中加载所有的 Excel 文件，并在树形列表中显示。
        """
        self.template_tree.clear()
        templates_folder = "./templates"
        if not os.path.exists(templates_folder):
            os.makedirs(templates_folder)

        # 列出 templates_folder 中的子目录，代表各部门或分类
        dirs = [d for d in os.listdir(templates_folder) if os.path.isdir(os.path.join(templates_folder, d))]

        # 处理子目录
        for dir_name in dirs:
            dir_path = os.path.join(templates_folder, dir_name)
            category_item = QTreeWidgetItem(self.template_tree)
            category_item.setText(0, dir_name)

            # 列出子目录中的 .xlsx 文件
            templates = [f for f in os.listdir(dir_path) if f.endswith('.xlsx')]
            for template in templates:
                template_item = QTreeWidgetItem(category_item)
                template_item.setText(0, template)
                # 存储模板的完整路径
                template_path = os.path.join(dir_path, template)
                template_item.setData(0, Qt.UserRole, template_path)

        # 处理直接位于 templates_folder 中的模板文件
        templates = [f for f in os.listdir(templates_folder) if f.endswith('.xlsx') and os.path.isfile(os.path.join(templates_folder, f))]
        if templates:
            uncategorized_item = QTreeWidgetItem(self.template_tree)
            uncategorized_item.setText(0, '未分类')
            for template in templates:
                template_item = QTreeWidgetItem(uncategorized_item)
                template_item.setText(0, template)
                template_path = os.path.join(templates_folder, template)
                template_item.setData(0, Qt.UserRole, template_path)

    def open_form(self):
        """打开表单填写窗口
        根据选择的模板，打开对应的表单填写窗口。
        """
        selected_item = self.template_tree.currentItem()
        if selected_item:
            # 检查是否为模板文件（叶子节点）
            if selected_item.childCount() == 0:
                template_path = selected_item.data(0, Qt.UserRole)
                if template_path:
                    # 获取模板名称用于配置加载
                    template_name = os.path.basename(template_path)
                    self.main_window.show_form_filling(template_name, template_path)
                else:
                    QMessageBox.warning(self, "警告", "无法获取模板路径！")
            else:
                QMessageBox.warning(self, "警告", "请选择一个表单模板！")
        else:
            QMessageBox.warning(self, "警告", "请选择一个表单模板！")