from PySide6.QtWidgets import QMainWindow, QStackedWidget


from windows.form_selection import FormSelectionWindow
from windows.template_a_form import TemplateAFormFillingWindow


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("表单辅助填写工具")
        self.setGeometry(300, 100, 800, 600)

        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)

        self.form_selection_window = FormSelectionWindow(self)
        self.form_filling_window = None  # 在需要时创建

        self.stacked_widget.addWidget(self.form_selection_window)

    def show_form_filling(self, template_name, template_path):
        if template_name == "鐵芯索樣申請表(2024年).xlsx":
            self.form_filling_window = TemplateAFormFillingWindow(template_name, template_path, self)
        # 其他表单
        self.stacked_widget.addWidget(self.form_filling_window)
        self.stacked_widget.setCurrentWidget(self.form_filling_window)

    def return_to_selection(self):
        self.stacked_widget.setCurrentWidget(self.form_selection_window)
        # 可根据需要移除填写界面
        self.stacked_widget.removeWidget(self.form_filling_window)
        self.form_filling_window = None