import os
import sqlite3
import json  # 添加import json

# 检查数据库文件是否存在
if not os.path.exists('form_data.db'):
    from create_database import create_database
    create_database()

from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QListWidget, QLabel, QMessageBox, QDialog, QLineEdit, QFormLayout, QComboBox, QCompleter,
                               QScrollArea, QFrame, QDateEdit)
from PySide6.QtGui import QIcon
from PySide6.QtCore import Qt, QDate
from datetime import datetime, timedelta
import win32com.client as win32
import openpyxl
from mapping import FIELD_MAPPING, FUNCTION_MAPPING
from email_templates import generate_email_body, load_email_template

def tuple_to_dict(fields, values):
    """将数据库查询返回的元组转换为字典"""
    return dict(zip(fields, values))

class FormSelectionWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("表单选择")
        self.setGeometry(300, 100, 400, 300)
        self.setWindowIcon(QIcon('icon.png'))
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        self.label = QLabel("请选择一个表单模板：")
        self.label.setStyleSheet("font-size: 16px; font-weight: bold;")
        self.layout.addWidget(self.label)

        self.template_list = QListWidget()
        self.template_list.setStyleSheet("font-size: 14px;")
        self.load_templates()
        self.layout.addWidget(self.template_list)

        self.button_layout = QHBoxLayout()

        self.select_button = QPushButton("选择")
        self.select_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.select_button.clicked.connect(self.open_form)
        self.button_layout.addWidget(self.select_button)

        self.refresh_button = QPushButton("刷新")
        self.refresh_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.refresh_button.clicked.connect(self.load_templates)
        self.button_layout.addWidget(self.refresh_button)

        self.layout.addLayout(self.button_layout)
        self.setLayout(self.layout)

    def load_templates(self):
        """加载模板列表
        从 './templates' 文件夹中加载所有的 Excel 文件，并在列表中显示。
        """
        self.template_list.clear()
        templates_folder = "./templates"
        if not os.path.exists(templates_folder):
            os.makedirs(templates_folder)

        templates = [f for f in os.listdir(templates_folder) if f.endswith('.xlsx')]
        for template in templates:
            self.template_list.addItem(template)

    def open_form(self):
        """打开表单填写窗口
        根据选择的模板，打开对应的表单填写窗口。
        """
        selected_item = self.template_list.currentItem()
        if (selected_item):
            selected_template = selected_item.text()
            self.form_filling_window = FormFillingWindow(selected_template, self)
            self.form_filling_window.exec()
        else:
            QMessageBox.warning(self, "警告", "请选择一个表单模板！")

class FormFillingWindow(QDialog):
    def __init__(self, template_name, parent=None):
        super().__init__(parent)
        self.template_name = template_name
        self.setWindowTitle(f"表单填写 - {template_name}")
        self.setGeometry(300, 100, 600, 600)
        self.setWindowIcon(QIcon('icon.png'))

        # 加载模板配置，包括字段关联逻辑
        self.dynamic_relations = self.load_template_config(template_name, "dynamic_relations")

        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)

        self.auto_load_layout = QFormLayout()
        self.required_layout = QFormLayout()
        self.optional_layout = QFormLayout()

        self.auto_load_fields = self.load_template_config(template_name, "auto_load", "fields")
        self.auto_load_types = self.load_template_config(template_name, "auto_load", "types")

        self.required_fields = self.load_template_config(template_name, "required", "fields")
        self.required_types = self.load_template_config(template_name, "required", "types")
        self.required_choices = self.load_template_config(template_name, "required", "choices")
        self.required_sources = self.load_template_config(template_name, "required", "source")

        self.optional_fields = self.load_template_config(template_name, "optional", "fields")
        self.optional_types = self.load_template_config(template_name, "optional", "types")
        self.optional_sources = self.load_template_config(template_name, "optional", "source")

        self.input_fields = {}

        # 定义 auto_load 字段的映射关系
        auto_load_field_mapping = {
            "Model Name": "model_name",
            "PN": "pn",
            "Vendor PN": "vendor_pn"
        }

        auto_load_label = QLabel("自动加载依据")
        auto_load_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.scroll_layout.addWidget(auto_load_label)
        self.create_fields(self.auto_load_layout, self.auto_load_fields, self.auto_load_types, field_mapping=auto_load_field_mapping)

        self.load_button = QPushButton("加载")
        self.load_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.load_button.clicked.connect(self.load_data)
        self.scroll_layout.addLayout(self.auto_load_layout)
        self.scroll_layout.addWidget(self.load_button)

        required_label = QLabel("必填")
        required_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.scroll_layout.addWidget(required_label)
        self.create_fields(self.required_layout, self.required_fields, self.required_types, self.required_choices, self.required_sources)

        self.scroll_layout.addLayout(self.required_layout)

        optional_label = QLabel("选填")
        optional_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.scroll_layout.addWidget(optional_label)
        self.create_fields(self.optional_layout, self.optional_fields, self.optional_types, sources=self.optional_sources)

        self.scroll_layout.addLayout(self.optional_layout)

        self.scroll_area.setWidget(self.scroll_content)
        self.layout.addWidget(self.scroll_area)

        self.button_layout = QHBoxLayout()
        self.finish_button = QPushButton("填写完成")
        self.finish_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.finish_button.clicked.connect(self.finish_form)
        self.button_layout.addWidget(self.finish_button)

        self.open_button = QPushButton("打开Excel")
        self.open_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.open_button.clicked.connect(self.open_excel)
        self.open_button.setEnabled(False)
        self.button_layout.addWidget(self.open_button)

        self.email_button = QPushButton("发送邮件")
        self.email_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.email_button.clicked.connect(self.send_email_wrapper)
        self.email_button.setEnabled(False)
        self.button_layout.addWidget(self.email_button)

        self.layout.addLayout(self.button_layout)

        self.setLayout(self.layout)

        # 提前填充 Apply Date 和 Request Date
        self.pre_fill_dates()

        # 初始化动态关联
        self.setup_dynamic_relations()

    def setup_dynamic_relations(self):
        """设置动态关联的信号和槽"""
        if isinstance(self.dynamic_relations, list):
            for relation in self.dynamic_relations:
                source_key = relation.get('source')
                if source_key in self.input_fields:
                    source_field = self.input_fields[source_key]
                    # 绑定信号
                    source_field.currentIndexChanged.connect(
                        lambda _, sk=source_key, rel=relation: self.update_related_fields(sk, rel))
                    # 初始化时自动更新关联字段
                    self.update_related_fields(source_key, relation)
        else:
            print("Dynamic relations is not a list. Please check the JSON structure.")

    def update_related_field(self, field_name, related_field_name):
        """更新关联字段的选项"""
        combo_box = self.input_fields.get(field_name)
        related_field = self.input_fields.get(related_field_name)

        if not combo_box or not isinstance(combo_box, QComboBox) or not related_field or not isinstance(related_field,
                                                                                                        QComboBox):
            return

        selected_value = combo_box.currentText().strip()

        # 获取对应的选项
        dynamic_choices = self.dynamic_relations[field_name]["values"].get(selected_value,
                                                                           self.dynamic_relations[field_name][
                                                                               "values"].get("default", []))

        # 更新关联字段的选项
        related_field.clear()
        related_field.addItems(dynamic_choices)

    def pre_fill_dates(self):
        """提前填充 Apply Date 和 Request Date"""
        if self.required_sources:
            for field, source in self.required_sources.items():
                if source.startswith("function:"):
                    func_name = source.split(":")[1]
                    func = FUNCTION_MAPPING.get(func_name)
                    if func:
                        value = func(*source.split(":")[2:]) if ":" in source else func()
                        self.input_fields.get(field, QLineEdit()).setText(value)

    def create_fields(self, layout, fields, types, choices=None, sources=None, field_mapping=None):
        """创建表单字段
        根据配置文件中的字段和类型信息，动态创建 QLineEdit 或 QComboBox 控件。

        参数:
        layout (QFormLayout): 字段所在的布局。
        fields (list): 字段名列表。
        types (dict): 字段类型字典，key 为字段名，value 为字段类型（如 combobox）。
        choices (dict): 字段选项字典，key 为字段名，value 为选项列表（仅用于 combobox）。
        sources (dict): 字段源字典，key 为字段名，value 为源信息（如 project:bg）。
        field_mapping (dict): 字段映射字典，key 为显示的字段名，value 为实际使用的字段名。
        """
        for field in fields:
            label = QLabel(field)
            label.setStyleSheet("font-size: 14px;")
            source = sources.get(field, field) if sources else field
            if ":" in source:
                source_key = field_mapping.get(field, source.split(":")[1]) if field_mapping else source.split(":")[1]
            else:
                source_key = field_mapping.get(field, source) if field_mapping else source

            if field in types and types[field] == "combobox":
                combo_box = QComboBox()
                if choices and field in choices:
                    combo_box.addItems(choices[field])
                combo_box.setCurrentIndex(-1)  # 初始时不选择任何选项
                layout.addRow(label, combo_box)
                self.input_fields[source_key] = combo_box

                # 检查并绑定动态关联
                if self.dynamic_relations:
                    for relation in self.dynamic_relations:
                        if relation['source'] == source_key:
                            combo_box.currentIndexChanged.connect(
                                lambda _, sk=source_key, rel=relation: self.update_related_fields(sk, rel))

            elif field in types and types[field] == "editable_combobox":
                combo_box = QComboBox()
                combo_box.setEditable(True)
                combo_box.setCompleter(QCompleter(combo_box.model(), self))
                combo_box.setMaxVisibleItems(7)
                if field == "Model Name":
                    combo_box.addItems(self.get_existing_model_names())
                elif field == "PN":
                    combo_box.addItems(self.get_existing_pns())
                elif field == "Vendor PN":
                    combo_box.addItems(self.get_existing_vendor_pns())
                elif field == "Apply Reason":
                    apply_reason_choices = self.required_choices.get("Apply Reason", [])
                    combo_box.addItems(apply_reason_choices)

                combo_box.setCurrentIndex(-1)  # 初始时不选择任何选项
                layout.addRow(label, combo_box)
                self.input_fields[source_key] = combo_box

            elif field in types and types[field] == "dateedit":
                date_edit = QDateEdit()
                date_edit.setCalendarPopup(True)
                date_edit.setDate(QDate.currentDate())  # 设置日期为默认值
                date_edit.clear()  # 清空默认显示的日期
                date_edit.lineEdit().setReadOnly(True)  # 禁用手动输入
                layout.addRow(label, date_edit)
                self.input_fields[source_key] = date_edit
            else:
                line_edit = QLineEdit()
                layout.addRow(label, line_edit)
                self.input_fields[source_key] = line_edit

            # 如果是需要提前填充的日期字段，立即填充
            if source.startswith("function:"):
                func_name = source.split(":")[1]
                func = FUNCTION_MAPPING.get(func_name)
                if func:
                    value = func(*source.split(":")[2:]) if ":" in source else func()
                    if isinstance(self.input_fields[source_key], QDateEdit):
                        self.input_fields[source_key].setDate(QDate.fromString(value, "yyyy-MM-dd"))
                    else:
                        self.input_fields[source_key].setText(value)

    def update_related_fields(self, source_key, relation):
        """更新动态关联字段的选项
        根据 source_key 的值更新与之相关联的目标字段的选项。

        参数:
        source_key (str): 触发关联的字段 key。
        relation (dict): 动态关联关系的定义，包括 source、target 和 mappings。
        """
        source_field = self.input_fields.get(source_key)
        if not source_field:
            return

        target_key = relation.get('target')
        if not target_key or target_key not in self.input_fields:
            return

        target_field = self.input_fields[target_key]
        target_field.clear()

        source_value = source_field.currentText()
        mappings = relation.get('mappings', {})
        if source_value in mappings:
            target_field.addItems(mappings[source_value])

    def get_existing_model_names(self):
        """从数据库获取现有的 Model Name 列表"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT model_name FROM projects")
        model_names = [row[0] for row in cursor.fetchall()]
        conn.close()
        return model_names

    def get_existing_pns(self):
        """从数据库获取现有的 PN 列表"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT pn FROM components")
        pns = [row[0] for row in cursor.fetchall()]
        conn.close()
        return pns

    def get_existing_vendor_pns(self):
        """从数据库获取现有的 Vendor PN 列表"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT vendor_pn FROM components")
        vendor_pns = [row[0] for row in cursor.fetchall()]
        conn.close()
        return vendor_pns

    def load_template_config(self, template_name, section, key=None):
        """加载模板配置文件
        从 JSON 配置文件中加载指定模板的配置信息。

        参数:
        template_name (str): 模板名称。
        section (str): 配置部分（如 auto_load, required）。
        key (str): 配置键（如 fields, types）。默认为 None，表示返回整个部分。

        返回:
        dict 或 list 或任何: 配置信息。
        """
        config_path = "templates_config.json"
        if not os.path.exists(config_path):
            QMessageBox.critical(self, "错误", "配置文件不存在！")
            return {}

        with open(config_path, 'r', encoding='utf-8') as file:
            config = json.load(file)

        section_data = config.get(template_name, {}).get(section, {})

        if key is not None:
            return section_data.get(key, {})

        return section_data

    def pre_fill_dates(self):
        """提前填充 Apply Date 和 Request Date"""
        if self.required_sources:
            for field, source in self.required_sources.items():
                if source.startswith("function:"):
                    func_name = source.split(":")[1]
                    func = FUNCTION_MAPPING.get(func_name)
                    if func:
                        value = func(*source.split(":")[2:]) if ":" in source else func()
                        if isinstance(self.input_fields.get(field, QLineEdit()), QDateEdit):
                            self.input_fields[field].setDate(QDate.fromString(value, "yyyy-MM-dd"))
                        else:
                            self.input_fields.get(field, QLineEdit()).setText(value)

    def load_data(self):
        """加载数据
        根据用户输入的 Model Name 或 PN，从数据库中加载项目和组件数据，并自动填充表单字段。
        """
        model_name = self.input_fields.get("model_name", None)
        pn = self.input_fields.get("pn", None)
        vendor_pn = self.input_fields.get("vendor_pn", None)

        model_name_text = model_name.currentText() if model_name else ""
        pn_text = pn.currentText() if pn else ""
        vendor_pn_text = vendor_pn.currentText() if vendor_pn else ""

        if not model_name_text and not pn_text and not vendor_pn_text:
            QMessageBox.warning(self, "警告", "请填写Model Name或PN或Vendor PN")
            return

        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()

        project_data = None
        component_data = None
        relation_data = None

        if model_name_text:
            cursor.execute("SELECT * FROM projects WHERE model_name=?", (model_name_text,))
            project_data = cursor.fetchone()

        if vendor_pn_text:
            cursor.execute("SELECT * FROM components WHERE vendor_pn=?", (vendor_pn_text,))
            component_data = cursor.fetchone()

        if model_name_text and vendor_pn_text:
            cursor.execute("SELECT * FROM projects_components WHERE project_model_name=? AND component_vendor_pn=?",
                           (model_name_text, vendor_pn_text))
            relation_data = cursor.fetchone()

        if not project_data and not component_data and not relation_data:
            QMessageBox.warning(self, "警告", "没有找到相关数据")
            return

        # 将元组转换为字典
        if project_data:
            project_data = dict(zip(FIELD_MAPPING["projects"].keys(), project_data))
        if component_data:
            component_data = dict(zip(FIELD_MAPPING["components"].keys(), component_data))
        if relation_data:
            relation_data = dict(zip(FIELD_MAPPING["projects_components"].keys(), relation_data))

        self.fill_data(project_data, component_data, relation_data)
        conn.close()

    def fill_data(self, project_data, component_data, relation_data):
        """填充表单数据
        根据从数据库加载的项目、组件和关联表数据，自动填充表单字段。

        参数:
        project_data (dict): 项目数据。
        component_data (dict): 组件数据。
        relation_data (dict): 关联表数据。
        """

        def set_field(field_name, value):
            field = self.input_fields.get(field_name)
            if field:
                if isinstance(field, QLineEdit):
                    field.setText(str(value))
                    # print(f"在{field_name}填入{value}類型LineEdit")
                elif isinstance(field, QComboBox):
                    index = field.findText(str(value))
                    if index >= 0:
                        field.setCurrentIndex(index)
                    else:
                        field.setEditText(str(value))
                        # print(f"在{field_name}填入{value}類型QComboBox")
                elif isinstance(field, QDateEdit):
                    field.setDate(QDate.fromString(value, "yyyy-MM-dd"))
                    # print(f"在{field_name}填入{value}類型QDateEdit")

        def get_source_value(source, project_data, component_data, relation_data):
            """获取字段值
            根据 source 的类型从项目数据、组件数据、关联表数据或函数中获取对应的值。
            """
            source_type, *params = source.split(":")
            if params:
                field_name = params[0]
                if source_type == "project" and project_data:
                    return project_data.get(field_name, "")
                elif source_type == "component" and component_data:
                    return component_data.get(field_name, "")
                elif source_type == "projects_components" and relation_data:
                    return relation_data.get(field_name, "")
                elif source_type == "function":
                    func = FUNCTION_MAPPING.get(field_name)
                    if func:
                        if len(params) > 1:
                            return func(*params[1:])
                        return func()
            return ""

        if project_data:
            for field_name in FIELD_MAPPING["projects"]:
                set_field(field_name, project_data[field_name])

        if component_data:
            for field_name in FIELD_MAPPING["components"]:
                set_field(field_name, component_data[field_name])

        if relation_data:
            for field_name in FIELD_MAPPING["projects_components"]:
                set_field(field_name, relation_data[field_name])

        all_fields = {**self.required_sources, **self.optional_sources}
        for field_name, source in all_fields.items():
            source_key = source.split(":")[1] if ":" in source else field_name
            value = get_source_value(source, project_data, component_data, relation_data)
            set_field(source_key, value)

    def validate_and_confirm(self):
        """验证表单"""
        missing_fields = []

        # 验证必填字段是否已填写
        for field in self.required_fields:
            source_key = self.get_source_key(field)
            input_field = self.input_fields.get(source_key)
            if isinstance(input_field, QLineEdit):
                if not input_field.text():
                    input_field.setStyleSheet("border: 1px solid red;")
                    missing_fields.append(field)
                else:
                    input_field.setStyleSheet("")  # 清除红色边框
            elif isinstance(input_field, QComboBox):
                if not input_field.currentText():
                    input_field.setStyleSheet("border: 1px solid red;")
                    missing_fields.append(field)
                else:
                    input_field.setStyleSheet("")  # 清除红色边框
            elif isinstance(input_field, QDateEdit):
                if not input_field.date().isValid():
                    input_field.setStyleSheet("border: 1px solid red;")
                    missing_fields.append(field)
                else:
                    input_field.setStyleSheet("")  # 清除红色边框

        if missing_fields:
            QMessageBox.warning(self, "警告", f"请填写必填项：{', '.join(missing_fields)}")
            return False

        return True

    def finish_form(self):
        """填写完成"""
        if not self.validate_and_confirm():
            return

        self.update_database()
        self.generate_form()

        # 锁定输入字段
        for field in self.input_fields.values():
            field.setDisabled(True)

        self.finish_button.setText("解锁")
        self.finish_button.clicked.disconnect()
        self.finish_button.clicked.connect(self.unlock_form)

        self.open_button.setEnabled(True)
        self.email_button.setEnabled(True)

    def unlock_form(self):
        """解锁表单"""
        for field in self.input_fields.values():
            field.setDisabled(False)

        self.finish_button.setText("填写完成")
        self.finish_button.clicked.disconnect()
        self.finish_button.clicked.connect(self.finish_form)

        self.open_button.setEnabled(False)
        self.email_button.setEnabled(False)

    def update_database(self):
        """更新数据库"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()

        project_data = {}
        component_data = {}

        # 收集用户输入的数据
        for field in FIELD_MAPPING["projects"].keys():
            input_field = self.input_fields.get(field)
            if isinstance(input_field, QLineEdit):
                project_data[field] = input_field.text()
            elif isinstance(input_field, QComboBox):
                project_data[field] = input_field.currentText()
            elif isinstance(input_field, QDateEdit):
                project_data[field] = input_field.date().toString("yyyy-MM-dd")

        for field in FIELD_MAPPING["components"].keys():
            input_field = self.input_fields.get(field)
            if isinstance(input_field, QLineEdit):
                component_data[field] = input_field.text()
            elif isinstance(input_field, QComboBox):
                component_data[field] = input_field.currentText()
            elif isinstance(input_field, QDateEdit):
                component_data[field] = input_field.date().toString("yyyy-MM-dd")

        # 确保所有必填字段都存在于 component_data 中
        for field in FIELD_MAPPING["components"].keys():
            if field not in component_data:
                component_data[field] = ""

        # 检查并更新项目数据
        model_name = project_data.get("model_name")
        cursor.execute("SELECT * FROM projects WHERE model_name=?", (model_name,))
        existing_project_tuple = cursor.fetchone()

        if existing_project_tuple:
            existing_project = tuple_to_dict(FIELD_MAPPING["projects"].keys(), existing_project_tuple)
            for key, value in project_data.items():
                if key in existing_project and value and value != existing_project[key]:
                    confirmation = QMessageBox.question(self, "确认更改",
                                                        f"项目字段 '{key}' 的值将从 '{existing_project[key]}' 更改为 '{value}'，是否确认？",
                                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if confirmation == QMessageBox.Yes:
                        cursor.execute(f"UPDATE projects SET {key}=? WHERE model_name=?", (value, model_name))
        else:
            # 新增项目数据
            cursor.execute('''
                INSERT INTO projects (model_name, bg, bu, model_forcast, end_customer, ee_name, product, location, mag_list, stage, rd_name, other_params, mp_date, lifecycle)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                project_data.get('model_name'), project_data.get('bg'), project_data.get('bu'),
                project_data.get('model_forcast'),
                project_data.get('end_customer'), project_data.get('ee_name'), project_data.get('product'),
                project_data.get('location'), project_data.get('mag_list'), project_data.get('stage'),
                project_data.get('rd_name'), project_data.get('other_params'), project_data.get('mp_date'),
                project_data.get('lifecycle')
            ))

        # 检查并更新组件数据
        vendor_pn = component_data.get("vendor_pn")
        cursor.execute("SELECT * FROM components WHERE vendor_pn=?", (vendor_pn,))
        existing_component_tuple = cursor.fetchone()

        if existing_component_tuple:
            existing_component = tuple_to_dict(FIELD_MAPPING["components"].keys(), existing_component_tuple)
            for key, value in component_data.items():
                if key in existing_component and value and value != existing_component[key]:
                    confirmation = QMessageBox.question(self, "确认更改",
                                                        f"组件字段 '{key}' 的值将从 '{existing_component[key]}' 更改为 '{value}'，是否确认？",
                                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if confirmation == QMessageBox.Yes:
                        cursor.execute(f"UPDATE components SET {key}=? WHERE vendor_pn=?", (value, vendor_pn))
        else:
            # 新增组件数据
            cursor.execute('''
                INSERT INTO components (vendor_pn, pn, revision, rd_name, drawn, supplier, core_type, delta_material, material_type, selection_orientation, material1, material2, material3, material4, material5, insulation_system, other_params, modify_from, price, ref_core_pn)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                component_data.get('vendor_pn'), component_data.get('pn'), component_data.get('revision'),
                component_data.get('rd_name'), component_data.get('drawn'),
                component_data.get('supplier'), component_data.get('core_type'), component_data.get('delta_material'),
                component_data.get('material_type'), component_data.get('selection_orientation'),
                component_data.get('material1'),
                component_data.get('material2'), component_data.get('material3'), component_data.get('material4'),
                component_data.get('material5'),
                component_data.get('insulation_system'), component_data.get('other_params'),
                component_data.get('modify_from'), component_data.get('price'),component_data.get('ref_core_pn'),
            ))

        # 更新关联表数据
        mag_type = ""
        forcast = ""

        mag_type_field = self.input_fields.get('mag_type')
        if mag_type_field:
            mag_type = mag_type_field.currentText() if isinstance(mag_type_field, QComboBox) else mag_type_field.text()

        forcast_field = self.input_fields.get('mag_forcast')
        if forcast_field:
            forcast = forcast_field.currentText() if isinstance(forcast_field, QComboBox) else forcast_field.text()

        cursor.execute("SELECT * FROM projects_components WHERE project_model_name=? AND component_vendor_pn=?",
                       (model_name, vendor_pn))
        existing_relation_tuple = cursor.fetchone()

        if existing_relation_tuple:
            existing_relation = tuple_to_dict(FIELD_MAPPING["projects_components"].keys(), existing_relation_tuple)
            for key, value in {"mag_type": mag_type, "location": project_data.get('location'),
                               "mag_forcast": forcast}.items():
                if key in existing_relation and value and value != existing_relation[key]:
                    confirmation = QMessageBox.question(self, "确认更改",
                                                        f"关联表字段 '{key}' 的值将从 '{existing_relation[key]}' 更改为 '{value}'，是否确认？",
                                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if confirmation == QMessageBox.Yes:
                        cursor.execute(
                            f"UPDATE projects_components SET {key}=? WHERE project_model_name=? AND component_vendor_pn=?",
                            (value, model_name, vendor_pn))
        else:
            # 新增关联表数据
            cursor.execute('''
                INSERT INTO projects_components (project_model_name, component_vendor_pn, mag_type, location, mag_forcast)
                VALUES (?, ?, ?, ?, ?)
            ''', (model_name, vendor_pn, mag_type, project_data.get('location'), forcast))

        conn.commit()
        conn.close()

        QMessageBox.information(self, "提示", "数据已更新，并生成表单！")

    def generate_form(self):
        """生成表单
        从模板读取数据并生成新的表单，填充用户输入的数据。
        """
        # 加载模板
        template_path = f"./templates/{self.template_name}"
        wb = openpyxl.load_workbook(template_path)
        ws = wb.active

        # 获取所有占位符并替换
        for row in ws.iter_rows():
            for cell in row:
                if cell.value and isinstance(cell.value, str) and "{" in cell.value and "}" in cell.value:
                    placeholder = cell.value
                    field_name = placeholder.strip("{}")
                    source_key = self.input_fields.get(field_name)
                    if source_key:
                        if isinstance(source_key, QLineEdit):
                            cell.value = source_key.text()
                        elif isinstance(source_key, QComboBox):
                            cell.value = source_key.currentText()
                        elif isinstance(source_key, QDateEdit):
                            cell.value = source_key.date().toString("yyyy-MM-dd")

        # 确保输出文件夹存在
        output_folder = "./output"
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # 动态生成文件名
        filename_format = self.load_template_config(self.template_name, "filename_format", None)
        apply_date = self.input_fields.get("current_date").date().toString("yyyy-MM-dd")  # 使用 current_date

        # 如果在 JSON 中有文件名格式，则使用该格式，否则使用默认格式
        if filename_format:
            # 使用 `get()` 检查字段是否存在并提供默认值
            core_type_field = self.input_fields.get("core_type")
            bu_field = self.input_fields.get("bu")
            vendor_PN = self.input_fields.get("vendor_PN")

            core_type = core_type_field.text() if core_type_field else "N/A"
            bu = bu_field.text() if bu_field else "N/A"
            vendor_pn = vendor_PN.text() if vendor_PN else "N/A"

            output_filename = filename_format.format(core_type=core_type, bu=bu, apply_date=apply_date, vendor_pn=vendor_pn)
        else:
            # 默认为表单名称
            output_filename = f"默認表單名_{self.template_name}_{apply_date}.xlsx"

        output_path = os.path.join(output_folder, output_filename)
        print(f"输出路径: {output_path}")  # 打印生成的文件路径以供检查

        # 保存新表单
        wb.save(output_path)

        self.generated_form_path = output_path

    def open_excel(self):
        """打开生成的 Excel 文件"""
        self.open_file(self.generated_form_path)

    def send_email_wrapper(self):
        """发送邮件并附加生成的 Excel 文件"""
        self.send_email(self.template_name, self.generated_form_path)

    def open_file(self, file_path):
        """打开生成的 Excel 文件"""
        os.startfile(file_path)

    def get_source_key(self, field):
        """获取字段的源键"""
        source = self.required_sources.get(field, field) if self.required_sources else field
        if ":" in source:
            return source.split(":")[1]
        return source

    def send_email(self, template_name, attachment_path):
        """发送邮件并附加生成的 Excel 文件"""
        attachment_path = os.path.abspath(attachment_path)
        print(f"邮件附件路径: {attachment_path}")  # 打印路径以供检查

        email_template = load_email_template(template_name)

        # 获取邮件信息
        subject_template = email_template.get("subject_template", "")
        recipients = email_template.get("recipients", [])
        cc_list = email_template.get("cc", [])

        # 替换模板中的占位符
        subject = subject_template.format(
            core_type=self.input_fields.get("core_type").currentText() if isinstance(self.input_fields.get("core_type"), QComboBox) else self.input_fields.get("core_type").text(),
            bu=self.input_fields.get("bu").currentText() if isinstance(self.input_fields.get("bu"), QComboBox) else self.input_fields.get("bu").text()
        )

        # 生成邮件正文
        body = generate_email_body(template_name, self.input_fields, self.get_source_key)

        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.Subject = subject
        mail.HTMLBody = body
        mail.To = ";".join(recipients)
        mail.CC = ";".join(cc_list)
        mail.Attachments.Add(attachment_path)
        mail.Display(False)  # 显示邮件窗口，但不锁死表单填写窗口

if __name__ == "__main__":
    app = QApplication([])
    window = FormSelectionWindow()
    window.show()
    app.exec()
