如果只是想修改表單顯示名稱：
1.修改templates_config.json中的對應名稱
2.修改email_templates中的對應名稱
可以通过在如下代码内增加print(source_key)来进行调试：
        for param in parameters:
            source_key = get_source_key(param)
            print(source_key)
            value = input_fields.get(source_key).currentText() if isinstance(input_fields.get(source_key),
                                                                             QComboBox) else input_fields.get(
                source_key).text()
3.如果修改的内容不存儲在數據庫中，那麽也需要修改模板Excel的替換符名稱
4.同上，邮件内的某些变量名稱也需要修改，否则对应邮件内容可能會无法顯示，如索样表里的“Remark”改成“Remarks”

如果想添加一个新的变量，如“Ref. Core PN”:"component:ref_core_pn"
# 修改templates_config.json
1. 在templates_config.json的"fields"中添加對應的名稱“Ref. Core PN”
2. 在templates_config.json的"types"中添加對應的類型如"combobox"、"dateedit"等，如果是普通的LineEdit可以不写
3. 如果上面是"combobox"等需要選項的類型，需要编辑选项在templates_config.json的"choices"中添加對應的選項，如"choices": {"component:ref_core_pn": ["PN1", "PN2", "PN3"]}
4. 如果是"editable_combobox", 还需要在main.py文件中create_fields函数中添加对应if语句
4. 在templates_config.json的"source"中绑定对应数据库中的变量名，如"source": {"Ref. Core PN": "component:ref_core_pn"}
5. 如果有关联类型选项，如"material_type"选择了"Ferrite",那么"delta_material"的选项需变更为["P93", "P90", "P94", "P95", "P952", "P953", "P97", "P50", "P502", "P52"],可以这样写
"dynamic_relations": [
            {
                "source": "material_type",
                "target": "delta_material",
                "mappings": {
                    "Ferrite": ["P93", "P90", "P94", "P95", "P952", "P953", "P97", "P50", "P502", "P52"],
                    "Alloy": ["KU", "KU3", "KU4", "KM", "KM2", "KM3", "UF", "UF2", "UF3", "HF", "HF2", "HF3", "MPP"],
                    "default": []
            }
        ]
# 修改create_database.py
1. 在create_database.py的"create_component_table"函数中添加對應的字段名和類型，如"ref_core_pn"和"text"
2. 在create_database.py的添加对应示例数据

# 修改mapping.py
1. 在mapping.py添加對應的映射，如在COMPONENT_FIELDS中添加"ref_core_pn" : "ref_core_pn"

# 修改main.py
1. 如果是"editable_combobox", 在main.py的create_fields函数中添加對應的if语句，如if field == "Apply Reason"
2. 如果有绑定数据库内容，需要更新update_database函数。在cursor.execute新增对应sql字段，并不要忘记VALUES数量要和INSERT INTO components对应

全部修改完毕后，重新执行create_database.py文件