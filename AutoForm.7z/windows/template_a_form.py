# windows/template_a_form.py
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QLineEdit, QComboBox, QDateEdit, QMessageBox, QFormLayout, QGridLayout
)
from PySide6.QtCore import Qt, QDate
from utils.database import (
    get_session, add_project, get_project_by_name,
    add_component, get_component_by_vendor_pn,
    add_project_component, get_all_model_names, get_all_vendor_pns
)
from utils.models import Project, Component, ProjectComponent
from utils.email_templates import generate_email_body
import openpyxl
import os

from .base_form import BaseFormFillingWindow

class TemplateAFormFillingWindow(BaseFormFillingWindow):
    def __init__(self, template_name, template_path, main_window):
        super().__init__(template_name, template_path, main_window)
        self.session = get_session()
        self.project = None
        self.component = None
        self.init_specific_ui()

    def init_specific_ui(self):
        """初始化特定表单的界面元素"""
        # 创建表单布局
        self.form_layout = QFormLayout()
        self.content_layout.addLayout(self.form_layout)

        # 加载机种信息部分
        self.load_section_label = QLabel("加载机种信息")
        self.load_section_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.form_layout.addRow(self.load_section_label)

        # Project Name (QComboBox)
        self.model_name_label = QLabel("Model Name:")
        self.model_name_input = QComboBox()
        self.model_name_input.setEditable(True)
        self.populate_model_names()
        self.model_name_input.setCurrentIndex(-1)  # 无选择
        self.form_layout.addRow(self.model_name_label, self.model_name_input)

        # Vendor PN (QComboBox)
        self.vendor_pn_label = QLabel("Vendor PN:")
        self.vendor_pn_input = QComboBox()
        self.vendor_pn_input.setEditable(True)
        self.populate_vendor_pns()
        self.vendor_pn_input.setCurrentIndex(-1)
        self.form_layout.addRow(self.vendor_pn_label, self.vendor_pn_input)

        # Load Button
        self.load_button = QPushButton("加载")
        self.load_button.clicked.connect(self.load_machine_info)
        self.form_layout.addRow("", self.load_button)

        # 必填信息部分
        self.required_section_label = QLabel("必填信息")
        self.required_section_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.form_layout.addRow(self.required_section_label)

        # BG 和 BU 放到同一行
        bg_bu_layout = QHBoxLayout()

        # BG
        self.bg_label = QLabel("BG:")
        self.bg_input = QLineEdit()
        bg_bu_layout.addWidget(self.bg_label)
        bg_bu_layout.addWidget(self.bg_input)

        # BU
        self.bu_label = QLabel("BU:")
        self.bu_input = QLineEdit()
        bg_bu_layout.addWidget(self.bu_label)
        bg_bu_layout.addWidget(self.bu_input)

        self.form_layout.addRow(bg_bu_layout)

        # Mag Design
        self.mag_design_label = QLabel("Mag Design:")
        self.mag_design_input = QLineEdit()
        self.form_layout.addRow(self.mag_design_label, self.mag_design_input)

        # Pilot Run On (Combobox)
        self.pilot_run_on_label = QLabel("Pilot Run On:")
        self.pilot_run_on_input = QComboBox()
        self.pilot_run_on_input.addItems(["DCWM", "DCZM", "DCGM", "DCUM", "DET", "DIN", "DEIC"])
        self.pilot_run_on_input.setCurrentIndex(-1)  # 无选择
        self.form_layout.addRow(self.pilot_run_on_label, self.pilot_run_on_input)

        # Forcast (QLineEdit + QComboBox)
        self.forcast_label = QLabel("Forcast:")
        self.forcast_input = QLineEdit()
        self.forcast_unit = QComboBox()
        self.forcast_unit.addItem("k/Mouth")
        self.forcast_unit.setEnabled(False)  # 不可更改
        self.forcast_unit.setCurrentIndex(-1)  # 无选择
        forcast_layout = QHBoxLayout()
        forcast_layout.addWidget(self.forcast_input)
        forcast_layout.addWidget(self.forcast_unit)
        self.form_layout.addRow(self.forcast_label, forcast_layout)

        # Selection Orientation (Combobox)
        self.selection_orientation_label = QLabel("Selection Orientation:")
        self.selection_orientation_input = QComboBox()
        self.selection_orientation_input.addItems(["价格", "性能"])
        self.selection_orientation_input.setCurrentIndex(-1)  # 无选择
        self.form_layout.addRow(self.selection_orientation_label, self.selection_orientation_input)

        # Material Type 和 Delta Material 放到同一行
        material_layout = QHBoxLayout()

        # Material Type
        self.material_type_label = QLabel("Material Type:")
        self.material_type_input = QComboBox()
        self.material_type_input.addItems(
            ["Ferrite", "Alloy", "Nanocrystalline", "NiZn", "Amorphous", "Si-Steel", "Iron"])
        self.material_type_input.setCurrentIndex(-1)  # 无选择
        self.material_type_input.currentIndexChanged.connect(self.update_delta_material_options)
        material_layout.addWidget(self.material_type_label)
        material_layout.addWidget(self.material_type_input)

        # Delta Material
        self.delta_material_label = QLabel("Delta Material:")
        self.delta_material_input = QComboBox()
        self.delta_material_input.setCurrentIndex(-1)  # 无选择
        material_layout.addWidget(self.delta_material_label)
        material_layout.addWidget(self.delta_material_input)

        self.form_layout.addRow(material_layout)

        # Supplier (Combobox)
        self.supplier_label = QLabel("Supplier:")
        self.supplier_input = QComboBox()
        self.supplier_input.addItems(["常規", "車用M", "博弈P", "家用H", "客戶指定"])
        self.supplier_input.setCurrentIndex(-1)  # 无选择
        self.form_layout.addRow(self.supplier_label, self.supplier_input)

        # Core Type (Text)
        self.core_type_label = QLabel("Core Type:")
        self.core_type_input = QLineEdit()
        self.form_layout.addRow(self.core_type_label, self.core_type_input)

        # Usage (Combobox)
        self.usage_label = QLabel("Usage:")
        self.usage_input = QComboBox()
        self.usage_input.addItems([
            "TRANSFORMER SENSOR",
            "TRANSFORMER MAIN",
            "TRANSFORMER AUX",
            "TRANSFORMER DRVR",
            "TRANSFORMER INV",
            "INDUCTOR",
            "INDUCTOR PFC",
            "LINE FILTER",
            "OTHERS"
        ])
        self.usage_input.setCurrentIndex(-1)  # 无选择
        self.form_layout.addRow(self.usage_label, self.usage_input)

        # Apply Date 和 Request Date 放到同一行
        date_layout = QHBoxLayout()

        # Apply Date
        self.apply_date_label = QLabel("Apply Date:")
        self.apply_date_input = QDateEdit()
        self.apply_date_input.setCalendarPopup(True)
        self.apply_date_input.setDate(QDate.currentDate())
        date_layout.addWidget(self.apply_date_label)
        date_layout.addWidget(self.apply_date_input)

        # Request Date
        self.request_date_label = QLabel("Request Date:")
        self.request_date_input = QDateEdit()
        self.request_date_input.setCalendarPopup(True)
        self.request_date_input.setDate(QDate.currentDate().addDays(14))
        date_layout.addWidget(self.request_date_label)
        date_layout.addWidget(self.request_date_input)

        self.form_layout.addRow(date_layout)

        # Quantity Requested (QLineEdit + QComboBox)
        self.quantity_requested_label = QLabel("Quantity Requested:")
        self.quantity_requested_input = QLineEdit()
        self.quantity_requested_unit = QComboBox()
        self.quantity_requested_unit.addItems(["PCS", "NPR", "SET"])
        self.quantity_requested_unit.setCurrentIndex(-1)  # 无选择
        quantity_layout = QHBoxLayout()
        quantity_layout.addWidget(self.quantity_requested_input)
        quantity_layout.addWidget(self.quantity_requested_unit)
        self.form_layout.addRow(self.quantity_requested_label, quantity_layout)

        # 选填内容部分
        self.optional_section_label = QLabel("选填内容")
        self.optional_section_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.form_layout.addRow(self.optional_section_label)

        # Remarks
        self.remarks_label = QLabel("Remarks:")
        self.remarks_input = QLineEdit()
        self.form_layout.addRow(self.remarks_label, self.remarks_input)

    def populate_model_names(self):
        """从数据库加载所有的 model_name 并填充到 QComboBox"""
        model_names = get_all_model_names(self.session)
        print(f"Model Names from DB: {model_names}")  # 调试信息
        self.model_name_input.addItems(model_names)

    def populate_vendor_pns(self):
        """从数据库加载所有的 vendor_pn 并填充到 QComboBox"""
        vendor_pns = get_all_vendor_pns(self.session)
        print(f"Vendor PNs from DB: {vendor_pns}")  # 调试信息
        self.vendor_pn_input.addItems(vendor_pns)

    def update_delta_material_options(self, index):
        """根据 Material Type 的选择，更新 Delta Material 的选项"""
        selected = self.material_type_input.currentText()
        mappings = {
            "Ferrite": ["P93", "P90", "P94", "P95", "P952", "P953", "P97", "P50", "P502", "P52"],
            "Alloy": ["KU", "KU3", "KU4", "KM", "KM2", "KM3", "UF", "UF2", "UF3", "HF", "HF2", "HF3", "MPP"],
            "Nanocrystalline": [],
            "NiZn": [],
            "Amorphous": [],
            "Si-Steel": [],
            "Iron": []
        }
        if selected in mappings and mappings[selected]:
            self.delta_material_input.addItems(mappings[selected])

    def load_machine_info(self):
        """加载项目名和 PN，填充相关字段"""
        model_name = self.model_name_input.currentText().strip()
        vendor_pn = self.vendor_pn_input.currentText().strip()

        if not model_name and not vendor_pn:
            QMessageBox.warning(self, "警告", "请填写 Model Name 或 Vendor PN")
            return

        project = None
        component = None
        relation = None

        # 查询项目数据
        if model_name:
            project = get_project_by_name(self.session, model_name)

        # 查询组件数据
        if vendor_pn:
            component = get_component_by_vendor_pn(self.session, vendor_pn)

        # 查询关联表数据（如果项目名和组件 PN 均填写）
        if model_name and vendor_pn:
            relation = self.session.query(ProjectComponent).filter_by(
                project_model_name=model_name,
                component_vendor_pn=vendor_pn
            ).first()

        # 填充项目数据
        if project:
            self.fill_project_data(project)

        # 填充组件数据
        if component:
            self.fill_component_data(component)

        # 填充关联表数据
        if relation:
            self.fill_relation_data(relation)

        # 如果都未找到，显示警告
        if not project and not component and not relation:
            QMessageBox.warning(self, "警告", "未找到相关数据")

    def fill_project_data(self, project):
        """根据项目数据填充表单"""
        self.bg_input.setText(project.bg or "")
        self.bu_input.setText(project.bu or "")
        self.mag_design_input.setText(project.rd_name or "")  # 根据 'Mag Design' 的来源
        self.pilot_run_on_input.setCurrentText(project.product or "")

        # 拆分 model_forcast
        if project.model_forcast:
            parts = project.model_forcast.split()
            if len(parts) == 2:
                self.forcast_input.setText(parts[0])
                self.forcast_unit.setCurrentText(parts[1])
            else:
                self.forcast_input.setText(project.model_forcast)
                self.forcast_unit.setCurrentText("k/Mouth")  # 默认单位
        else:
            self.forcast_input.setText("")
            self.forcast_unit.setCurrentText("k/Mouth")

        # 其他字段根据需要填充

    def fill_component_data(self, component):
        """根据组件数据填充表单"""
        self.core_type_input.setText(component.core_type or "")
        self.material_type_input.setCurrentText(component.material_type or "")
        self.delta_material_input.setCurrentText(component.delta_material or "")
        self.selection_orientation_input.setCurrentText(component.selection_orientation or "")
        self.supplier_input.setCurrentText(component.supplier or "")
        # 其他字段根据需要填充

    def fill_relation_data(self, relation):
        """根据关联表数据填充表单"""
        # 填充关联表中特有的数据，如位置、用量等
        self.usage_input.setCurrentText(relation.mag_type or "")


    def validate_required_fields(self):
        """验证必填项是否已填写"""
        missing_fields = []

        # List of required fields and their inputs
        required = {
            "BG": self.bg_input,
            "BU": self.bu_input,
            "Mag Design": self.mag_design_input,
            "Pilot Run On": self.pilot_run_on_input,
            "Forcast": self.forcast_input,  # QLineEdit + QComboBox
            "Selection Orientation": self.selection_orientation_input,
            "Material Type": self.material_type_input,
            "Delta Material": self.delta_material_input,
            "Supplier": self.supplier_input,
            "Core Type": self.core_type_input,
            "Usage": self.usage_input,
            "Apply Date": self.apply_date_input,
            "Request Date": self.request_date_input,
            "Quantity Requested": self.quantity_requested_input,
            "Quantity Unit": self.quantity_requested_unit
        }

        # 验证必填字段
        for field, widget in required.items():
            if isinstance(widget, QLineEdit):
                if not widget.text().strip():
                    missing_fields.append(field)
                    widget.setStyleSheet("border: 1px solid red;")
                else:
                    widget.setStyleSheet("")
            elif isinstance(widget, QComboBox):
                if not widget.currentText().strip():
                    missing_fields.append(field)
                    widget.setStyleSheet("border: 1px solid red;")
                else:
                    widget.setStyleSheet("")
            elif isinstance(widget, QDateEdit):
                if not widget.date().isValid():
                    missing_fields.append(field)
                    widget.setStyleSheet("border: 1px solid red;")
                else:
                    widget.setStyleSheet("")

        # 确保 Mag Design 始终为必填项
        if not self.mag_design_input.text().strip():
            missing_fields.append("Mag Design")
            self.mag_design_input.setStyleSheet("border: 1px solid red;")
        else:
            self.mag_design_input.setStyleSheet("")

        if missing_fields:
            QMessageBox.warning(self, "警告", f"请填写必填项：{', '.join(set(missing_fields))}")
            return False

        return True

    def update_database(self):
        """保存数据到数据库，并在必要时提示用户覆盖现有数据"""
        # 获取表单数据
        forcast_value = self.forcast_input.text().strip()
        forcast_unit = self.forcast_unit.currentText()
        forcast_combined = f"{forcast_value} {forcast_unit}" if forcast_value else ""
        quantity_requested_value = self.quantity_requested_input.text().strip()
        quantity_requested_unit = self.quantity_requested_unit.currentText()
        quantity_requested_combined = f"{quantity_requested_value} {quantity_requested_unit}" if quantity_requested_value else ""

        project_data = {
            "model_name": self.model_name_input.currentText().strip(),
            "bg": self.bg_input.text().strip(),
            "bu": self.bu_input.text().strip(),
            "model_forcast": forcast_combined,  # 存储为字符串
            "end_customer": getattr(self, 'end_customer_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                                       'end_customer_input') else "",
            "ee_name": getattr(self, 'ee_name_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                             'ee_name_input') else "",
            "product": self.pilot_run_on_input.currentText(),
            "mag_list": getattr(self, 'mag_list_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                               'mag_list_input') else "",
            "stage": getattr(self, 'stage_input', QLineEdit()).text().strip() if hasattr(self, 'stage_input') else "",
            "mag_type": self.usage_input.currentText(),
            "rd_name": self.mag_design_input.text().strip(),
            "location": "",  # 已删除 location
            "other_params": getattr(self, 'other_params_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                                       'other_params_input') else "",
            "mp_date": getattr(self, 'mp_date_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                             'mp_date_input') else "",
            "lifecycle": getattr(self, 'lifecycle_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                                 'lifecycle_input') else ""
        }

        component_data = {
            "vendor_pn": self.vendor_pn_input.currentText().strip(),
            "pn": getattr(self, 'pn_input', QLineEdit()).text().strip() if hasattr(self, 'pn_input') else "",
            "revision": getattr(self, 'revision_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                               'revision_input') else "",
            "rd_name": getattr(self, 'rd_name_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                             'rd_name_input') else "",
            "drawn": getattr(self, 'drawn_input', QLineEdit()).text().strip() if hasattr(self, 'drawn_input') else "",
            "supplier": self.supplier_input.currentText(),
            "core_type": self.core_type_input.text().strip(),
            "delta_material": self.delta_material_input.currentText(),
            "material_type": self.material_type_input.currentText(),
            "selection_orientation": self.selection_orientation_input.currentText(),
            "insulation_system": getattr(self, 'insulation_system_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                                                 'insulation_system_input') else "",
            "other_params": getattr(self, 'component_other_params_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                                                 'component_other_params_input') else "",
            "modify_from": getattr(self, 'modify_from_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                                     'modify_from_input') else "",
            "price": float(getattr(self, 'price_input', QLineEdit()).text().strip()) if hasattr(self,
                                                                                                'price_input') and self.price_input.text().strip() else 0.0,
            "ref_core_pn": getattr(self, 'ref_core_pn_input', QLineEdit()).text().strip() if hasattr(self,
                                                                                                     'ref_core_pn_input') else ""
        }

        # 添加或更新项目
        existing_project = get_project_by_name(self.session, project_data['model_name'])
        existing_component = get_component_by_vendor_pn(self.session, component_data['vendor_pn'])
        existing_relation = None
        if project_data['model_name'] and component_data['vendor_pn']:
            existing_relation = self.session.query(ProjectComponent).filter_by(
                project_model_name=project_data['model_name'],
                component_vendor_pn=component_data['vendor_pn']
            ).first()

        # 检查是否存在差异
        data_differs = False
        if existing_project:
            for key, value in project_data.items():
                if getattr(existing_project, key) != value:
                    data_differs = True
                    break

        if existing_component:
            for key, value in component_data.items():
                if getattr(existing_component, key) != value:
                    data_differs = True
                    break

        if existing_relation:
            # 比较关联表的字段
            if existing_relation.mag_type != project_data['mag_type']:
                data_differs = True
            if existing_relation.mag_forcast != float(forcast_value) if forcast_value else 0.0:
                data_differs = True

        if data_differs:
            # 弹出警告框询问是否覆盖
            reply = QMessageBox.question(
                self,
                "确认覆盖",
                "检测到表单中的数据与数据库中的现有数据不同。是否确认覆盖现有数据？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            if reply == QMessageBox.No:
                return  # 用户选择不覆盖，终止操作

        # 如果用户选择覆盖或数据无差异，则继续保存
        try:
            # 添加或更新项目
            add_project(self.session, project_data)

            # 添加或更新组件
            add_component(self.session, component_data)

            # 添加或更新关联表
            mag_forcast_number = float(forcast_value) if forcast_value else 0.0
            add_project_component(
                self.session,
                project_model_name=project_data['model_name'],
                component_vendor_pn=component_data['vendor_pn'],
                mag_type=self.usage_input.currentText(),
                location="",  # 已删除 location
                mag_forcast=mag_forcast_number  # 仅保存数字部分
            )

            QMessageBox.information(self, "成功", "数据已成功保存到数据库。")
        except ValueError as ve:
            QMessageBox.critical(self, "错误", f"转换 Forcast 数量失败: {ve}")
            self.session.rollback()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"保存数据时出错: {e}")
            self.session.rollback()

    def replace_placeholders_and_save(self):
        """替换 Excel 模板中的占位符，并保存到 output 文件夹"""
        # 加载模板
        wb = openpyxl.load_workbook(self.template_path)
        ws = wb.active

        # 替换占位符
        for row in ws.iter_rows():
            for cell in row:
                if cell.value and isinstance(cell.value, str) and "{" in cell.value and "}" in cell.value:
                    placeholder = cell.value.strip("{}")
                    value = self.get_field_value(placeholder)
                    cell.value = value

        # 确保输出文件夹存在
        output_folder = "./output"
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # 生成文件名，替换非法字符
        filename_format = "{core_type}-索樣申請單 FOR {bu}BU {apply_date}.xlsx"
        apply_date = self.apply_date_input.date().toString("yyyy-MM-dd")
        core_type = self.core_type_input.text().strip().replace("/", "-").replace("\\", "-").replace(":", "-")
        bu = self.bu_input.text().strip().replace("/", "-").replace("\\", "-").replace(":", "-")

        output_filename = filename_format.format(core_type=core_type, bu=bu, apply_date=apply_date)
        output_path = os.path.join(output_folder, output_filename)

        # 保存新表单
        wb.save(output_path)
        self.generated_form_path = output_path

    def get_field_value(self, field_name):
        """获取对应字段的值"""
        field_mapping = {
            "Model Name": self.model_name_input.currentText().strip(),
            "Mag Design": self.mag_design_input.text().strip(),
            "BG": self.bg_input.text().strip(),
            "BU": self.bu_input.text().strip(),
            "Pilot Run On": self.pilot_run_on_input.currentText(),
            "Core Type": self.core_type_input.text().strip(),
            "Supplier": self.supplier_input.currentText(),
            "Delta Material": self.delta_material_input.currentText(),
            "Material Type": self.material_type_input.currentText(),
            "Selection Orientation": self.selection_orientation_input.currentText(),
            "Usage": self.usage_input.currentText(),
            "Forcast": self.forcast_input.text().strip() + " " + self.forcast_unit.currentText(),
            "Apply Date": self.apply_date_input.date().toString("yyyy-MM-dd"),
            "Request Date": self.request_date_input.date().toString("yyyy-MM-dd"),
            "Quantity Requested": self.quantity_requested_input.text().strip() + " " + self.quantity_requested_unit.currentText(),
            "Remarks": self.remarks_input.text().strip()
        }
        return field_mapping.get(field_name, "")
