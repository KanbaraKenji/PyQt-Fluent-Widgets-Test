# utils/create_database.py
from database import initialize_database

def create_database():
    initialize_database()
    print("数据库已初始化")

if __name__ == "__main__":
    create_database()
