# utils/models.py
from sqlalchemy import Column, String, Float, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

# 关联表，用于 components 和 materials 的多对多关系
component_materials = Table(
    'component_materials', Base.metadata,
    Column('component_vendor_pn', String, ForeignKey('components.vendor_pn'), primary_key=True),
    Column('material_id', String, ForeignKey('materials.id'), primary_key=True)
)


class Project(Base):
    __tablename__ = 'projects'
    model_name = Column(String, primary_key=True, unique=True, nullable=False)
    bg = Column(String)
    bu = Column(String)
    model_forcast = Column(String)  # 改为 String 以存储带单位的值
    end_customer = Column(String)
    ee_name = Column(String)
    product = Column(String)
    mag_list = Column(String)
    stage = Column(String)
    rd_name = Column(String)
    location = Column(String, nullable=True)  # 可选字段
    other_params = Column(String)
    mp_date = Column(String)  # 或使用 Date 类型
    lifecycle = Column(String)

    components = relationship("ProjectComponent", back_populates="project")


class Component(Base):
    __tablename__ = 'components'
    vendor_pn = Column(String, primary_key=True, unique=True, nullable=False)
    pn = Column(String)
    revision = Column(String)
    rd_name = Column(String)
    drawn = Column(String)
    supplier = Column(String)
    core_type = Column(String)
    delta_material = Column(String)
    material_type = Column(String)
    selection_orientation = Column(String)
    insulation_system = Column(String)
    other_params = Column(String)
    modify_from = Column(String)
    price = Column(Float)
    ref_core_pn = Column(String)

    # 材料关联
    materials = relationship('Material', secondary=component_materials, back_populates='components')

    projects = relationship("ProjectComponent", back_populates="component")


class Material(Base):
    __tablename__ = 'materials'
    id = Column(String, primary_key=True, unique=True, nullable=False)  # 假设每个材料有唯一的ID
    name = Column(String)

    components = relationship('Component', secondary=component_materials, back_populates='materials')


# 关联表，存储项目和组件的特定关系
class ProjectComponent(Base):
    __tablename__ = 'projects_components'
    project_model_name = Column(String, ForeignKey('projects.model_name'), primary_key=True)
    component_vendor_pn = Column(String, ForeignKey('components.vendor_pn'), primary_key=True)
    mag_type = Column(String)
    location = Column(String, nullable=True)  # 可选字段
    mag_forcast = Column(Float)

    project = relationship("Project", back_populates="components")
    component = relationship("Component", back_populates="projects")
