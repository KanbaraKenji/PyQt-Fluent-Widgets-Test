import json
from PySide6.QtWidgets import QComboBox, QMessageBox
import win32com.client as win32
import os

# def load_email_template(template_name):
#     """加载指定模板的邮件配置信息"""
#     with open('../email_templates.json', 'r', encoding='utf-8') as file:
#         templates = json.load(file)
#     return templates.get(template_name, {})


def generate_email_body(template_name, get_field_value, recipient_name):
    """生成邮件正文"""

    if template_name == "鐵芯索樣申請表(2024年).xlsx":
        parameters = [
            "BG", "BU", "Mag Design", "Pilot Run On", "Forcast",
            "Selection Orientation", "Material Type", "Supplier",
            "Delta Material", "Core Type", "Usage", "Apply Date",
            "Request Date", "Quantity Requested"
        ]

        parameters_table = """
        <style>
            body { font-family: 'Microsoft YaHei', Arial, sans-serif; }
            table { border-collapse: collapse; width: auto; margin: 0 auto; }
            th, td { border: 2px solid black; padding: 4px; }
            th { font-weight: bold; background-color: #d9d9d9; text-align: center; }
            td { text-align: center; }
        </style>
        <table>
            <tr><th>项目</th><th>参数</th></tr>"""

        for param in parameters:
            value = get_field_value(param)
            parameters_table += f"<tr><td style='text-align: left;'>{param}</td><td style='background-color: #FFFF00;'>{value}</td></tr>"
        parameters_table += "</table>"

        remark = get_field_value("Remarks")

        if remark:
            remark_html = f"<p><strong><u>Remark: {remark}</u></strong></p>"
        else:
            remark_html = ""

        body_template = f"""
        <html>
        <head>
            <style>
                body {{ font-family: 'Microsoft YaHei', Arial, sans-serif; }}
            </style>
        </head>
        <body>
            <p>Dear {recipient_name},</p>
            <p>請協助向廠商詢價與索樣，謝謝！</p>
            {remark_html}
            <p>資訊如下:</p>
            {parameters_table}
            <p>鐵心尺寸截圖如下:</p>
            <p></p>
            <p>Best Regards！</p>
        </body>
        </html>
        """
    else:
        body_template = """
        <html>
        <head>
            <style>
                body { font-family: 'Microsoft YaHei', Arial, sans-serif; }
            </style>
        </head>
        <body>
            <p>Dear {recipient_name},</p>
            <p>请查看附件</p>
        </body>
        </html>
        """
    return body_template

def send_email(template_name, get_field_value, attachment_path=None):
    """发送邮件并附加生成的 Excel 文件

    参数:
    - template_name: 表单模板名称，用于选择邮件模板。
    - get_field_value: 函数，用于获取表单字段的值。
    - attachment_path: 可选，附件文件的路径。
    """

    attachment_path = os.path.abspath(attachment_path) if attachment_path else None

    # 根据 template_name 选择不同的邮件配置
    if template_name == "鐵芯索樣申請表(2024年).xlsx":
        recipients = ["ODIN.YT.HUANG@deltaww.com"]
        cc_list = ["Rita.Wang@deltaww.com", "Hong.ju@deltaww.com"]
        subject_template = "{Core_Type}索樣申請 FOR {BU}BU"
    else:
        # 默认配置或其他模板的配置
        recipients = []
        cc_list = []
        subject_template = "Default Subject"

    # 获取 recipient_name
    if recipients:
        # 从第一个收件人的邮箱中提取名字部分
        first_recipient = recipients[0]
        recipient_name = first_recipient.split('@')[0].split('.')[
            0].capitalize()  # e.g., "Odin" from "ODIN.YT.HUANG@deltaww.com"
    else:
        recipient_name = " "

    # 替换占位符以生成邮件主题
    try:
        subject = subject_template.format(
            Core_Type=get_field_value("Core Type"),
            BU=get_field_value("BU")
        )
    except KeyError as e:
        QMessageBox.critical(None, "错误", f"缺少字段用于生成主题: {e}")
        return

    # 生成邮件正文
    body = generate_email_body(template_name, get_field_value, recipient_name)

    # 发送邮件
    try:
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.Subject = subject
        mail.HTMLBody = body
        mail.To = ";".join(recipients)
        mail.CC = ";".join(cc_list)
        if attachment_path:
            mail.Attachments.Add(attachment_path)
        mail.Display(False)  # 显示邮件窗口，但不锁死表单填写窗口
    except Exception as e:
        QMessageBox.critical(None, "发送邮件失败", f"无法发送邮件: {e}")
