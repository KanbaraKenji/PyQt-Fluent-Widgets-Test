# alembic/versions/ed10f35e6302_initial_migration.py
"""Initial migration

Revision ID: ed10f35e6302
Revises:
Create Date: 2024-10-21 12:34:56.789012

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'ed10f35e6302'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    # 创建 projects 表
    op.create_table(
        'projects',
        sa.Column('model_name', sa.String(), primary_key=True, nullable=False),
        sa.Column('bg', sa.String(), nullable=True),
        sa.Column('bu', sa.String(), nullable=True),
        sa.Column('model_forcast', sa.String(), nullable=True),
        sa.Column('end_customer', sa.String(), nullable=True),
        sa.Column('ee_name', sa.String(), nullable=True),
        sa.Column('product', sa.String(), nullable=True),
        sa.Column('mag_list', sa.String(), nullable=True),
        sa.Column('stage', sa.String(), nullable=True),
        sa.Column('rd_name', sa.String(), nullable=True),
        sa.Column('location', sa.String(), nullable=True),
        sa.Column('other_params', sa.String(), nullable=True),
        sa.Column('mp_date', sa.String(), nullable=True),
        sa.Column('lifecycle', sa.String(), nullable=True)
    )

    # 创建 components 表
    op.create_table(
        'components',
        sa.Column('vendor_pn', sa.String(), primary_key=True, nullable=False),
        sa.Column('pn', sa.String(), nullable=True),
        sa.Column('revision', sa.String(), nullable=True),
        sa.Column('rd_name', sa.String(), nullable=True),
        sa.Column('drawn', sa.String(), nullable=True),
        sa.Column('supplier', sa.String(), nullable=True),
        sa.Column('core_type', sa.String(), nullable=True),
        sa.Column('delta_material', sa.String(), nullable=True),
        sa.Column('material_type', sa.String(), nullable=True),
        sa.Column('selection_orientation', sa.String(), nullable=True),
        sa.Column('insulation_system', sa.String(), nullable=True),
        sa.Column('other_params', sa.String(), nullable=True),
        sa.Column('modify_from', sa.String(), nullable=True),
        sa.Column('price', sa.Float(), nullable=True),
        sa.Column('ref_core_pn', sa.String(), nullable=True)
    )

    # 创建 materials 表
    op.create_table(
        'materials',
        sa.Column('id', sa.String(), primary_key=True, nullable=False),
        sa.Column('name', sa.String(), nullable=True)
    )

    # 创建 component_materials 关联表
    op.create_table(
        'component_materials',
        sa.Column('component_vendor_pn', sa.String(), sa.ForeignKey('components.vendor_pn'), primary_key=True),
        sa.Column('material_id', sa.String(), sa.ForeignKey('materials.id'), primary_key=True)
    )

    # 创建 projects_components 关联表
    op.create_table(
        'projects_components',
        sa.Column('project_model_name', sa.String(), sa.ForeignKey('projects.model_name'), primary_key=True),
        sa.Column('component_vendor_pn', sa.String(), sa.ForeignKey('components.vendor_pn'), primary_key=True),
        sa.Column('mag_type', sa.String(), nullable=True),
        sa.Column('location', sa.String(), nullable=True),
        sa.Column('mag_forcast', sa.Float(), nullable=True),
        sa.ForeignKeyConstraint(['project_model_name'], ['projects.model_name']),
        sa.ForeignKeyConstraint(['component_vendor_pn'], ['components.vendor_pn'])
    )

def downgrade():
    # 删除表的顺序应与创建表的顺序相反，以避免外键约束错误
    op.drop_table('projects_components')
    op.drop_table('component_materials')
    op.drop_table('materials')
    op.drop_table('components')
    op.drop_table('projects')
