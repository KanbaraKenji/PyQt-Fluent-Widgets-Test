from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QListWidget, QLabel, QMessageBox, QDialog, QLineEdit, QFormLayout, QComboBox, QCompleter, QScrollArea, QFrame)
from PySide6.QtGui import QIcon
from PySide6.QtCore import Qt
from datetime import datetime, timedelta
import win32com.client as win32
import openpyxl
from mapping import FIELD_MAPPING, FUNCTION_MAPPING

import os
import sqlite3
import json  # 添加import json

# 检查数据库文件是否存在
if not os.path.exists('form_data.db'):
    from create_database import create_database
    create_database()

def tuple_to_dict(fields, values):
    """将数据库查询返回的元组转换为字典"""
    return dict(zip(fields, values))

class FormSelectionWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("表单选择")
        self.setGeometry(300, 100, 400, 300)
        self.setWindowIcon(QIcon('icon.png'))
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        self.label = QLabel("请选择一个表单模板：")
        self.label.setStyleSheet("font-size: 16px; font-weight: bold;")
        self.layout.addWidget(self.label)

        self.template_list = QListWidget()
        self.template_list.setStyleSheet("font-size: 14px;")
        self.load_templates()
        self.layout.addWidget(self.template_list)

        self.button_layout = QHBoxLayout()

        self.select_button = QPushButton("选择")
        self.select_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.select_button.clicked.connect(self.open_form)
        self.button_layout.addWidget(self.select_button)

        self.refresh_button = QPushButton("刷新")
        self.refresh_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.refresh_button.clicked.connect(self.load_templates)
        self.button_layout.addWidget(self.refresh_button)

        self.layout.addLayout(self.button_layout)
        self.setLayout(self.layout)

    def load_templates(self):
        """加载模板列表
        从 './templates' 文件夹中加载所有的 Excel 文件，并在列表中显示。
        """
        self.template_list.clear()
        templates_folder = "./templates"
        if not os.path.exists(templates_folder):
            os.makedirs(templates_folder)

        templates = [f for f in os.listdir(templates_folder) if f.endswith('.xlsx')]
        for template in templates:
            self.template_list.addItem(template)

    def open_form(self):
        """打开表单填写窗口
        根据选择的模板，打开对应的表单填写窗口。
        """
        selected_item = self.template_list.currentItem()
        if selected_item:
            selected_template = selected_item.text()
            self.form_filling_window = FormFillingWindow(selected_template, self)
            self.form_filling_window.exec()
        else:
            QMessageBox.warning(self, "警告", "请选择一个表单模板！")

class FormFillingWindow(QDialog):
    def __init__(self, template_name, parent=None):
        super().__init__(parent)
        self.template_name = template_name
        self.setWindowTitle(f"表单填写 - {template_name}")
        self.setGeometry(300, 100, 600, 600)
        self.setWindowIcon(QIcon('icon.png'))

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)

        self.main_widget = QWidget()
        self.scroll_area.setWidget(self.main_widget)

        self.layout = QVBoxLayout(self.main_widget)
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.layout.setSpacing(15)

        self.auto_load_layout = QFormLayout()
        self.required_layout = QFormLayout()
        self.optional_layout = QFormLayout()

        self.auto_load_fields = self.load_template_config(template_name, "auto_load", "fields")
        self.auto_load_types = self.load_template_config(template_name, "auto_load", "types")

        self.required_fields = self.load_template_config(template_name, "required", "fields")
        self.required_types = self.load_template_config(template_name, "required", "types")
        self.required_choices = self.load_template_config(template_name, "required", "choices")
        self.required_sources = self.load_template_config(template_name, "required", "source")

        self.optional_fields = self.load_template_config(template_name, "optional", "fields")
        self.optional_types = self.load_template_config(template_name, "optional", "types")
        self.optional_sources = self.load_template_config(template_name, "optional", "source")

        self.input_fields = {}

        auto_load_field_mapping = {
            "Model Name": "model_name",
            "PN": "pn",
            "Vendor PN": "vendor_pn"
        }

        auto_load_label = QLabel("自动加载依据")
        auto_load_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.layout.addWidget(auto_load_label)
        self.create_fields(self.auto_load_layout, self.auto_load_fields, self.auto_load_types, field_mapping=auto_load_field_mapping)

        self.load_button = QPushButton("加载")
        self.load_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.load_button.clicked.connect(self.load_data)
        self.layout.addLayout(self.auto_load_layout)
        self.layout.addWidget(self.load_button)

        required_label = QLabel("必填")
        required_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.layout.addWidget(required_label)
        self.create_fields(self.required_layout, self.required_fields, self.required_types, self.required_choices, self.required_sources)

        self.layout.addLayout(self.required_layout)

        optional_label = QLabel("选填")
        optional_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.layout.addWidget(optional_label)
        self.create_fields(self.optional_layout, self.optional_fields, self.optional_types, sources=self.optional_sources)

        self.layout.addLayout(self.optional_layout)

        self.finish_button = QPushButton("填写完成")
        self.finish_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.finish_button.clicked.connect(self.finish_form)
        self.layout.addWidget(self.finish_button)

        self.open_excel_button = QPushButton("打开Excel")
        self.open_excel_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.open_excel_button.clicked.connect(self.open_excel)
        self.open_excel_button.setEnabled(False)  # 默认不可点击
        self.layout.addWidget(self.open_excel_button)

        self.send_email_button = QPushButton("发送邮件")
        self.send_email_button.setStyleSheet("font-size: 14px; padding: 5px 15px;")
        self.send_email_button.clicked.connect(self.send_email_wrapper)
        self.send_email_button.setEnabled(False)  # 默认不可点击
        self.layout.addWidget(self.send_email_button)

        self.setLayout(self.layout)

    def create_fields(self, layout, fields, types, choices=None, sources=None, field_mapping=None):
        """创建表单字段
        根据配置文件中的字段和类型信息，动态创建 QLineEdit 或 QComboBox 控件。

        参数:
        layout (QFormLayout): 字段所在的布局。
        fields (list): 字段名列表。
        types (dict): 字段类型字典，key 为字段名，value 为字段类型（如 combobox）。
        choices (dict): 字段选项字典，key 为字段名，value 为选项列表（仅用于 combobox）。
        sources (dict): 字段源字典，key 为字段名，value 为源信息（如 project:bg）。
        field_mapping (dict): 字段映射字典，key 为显示的字段名，value 为实际使用的字段名。
        """
        for field in fields:
            label = QLabel(field)
            label.setStyleSheet("font-size: 14px;")
            source = sources.get(field, field) if sources else field
            if ":" in source:
                source_key = field_mapping.get(field, source.split(":")[1]) if field_mapping else source.split(":")[1]
            else:
                source_key = field_mapping.get(field, source) if field_mapping else source

            if field in types and types[field] == "combobox":
                combo_box = QComboBox()
                if choices and field in choices:
                    combo_box.addItems(choices[field])
                layout.addRow(label, combo_box)
                self.input_fields[source_key] = combo_box
            elif field in types and types[field] == "editable_combobox":
                combo_box = QComboBox()
                combo_box.setEditable(True)
                combo_box.setCompleter(QCompleter(combo_box.model(), self))
                combo_box.setMaxVisibleItems(7)
                if field == "Model Name":
                    combo_box.addItems(self.get_existing_model_names())
                elif field == "PN":
                    combo_box.addItems(self.get_existing_pns())
                elif field == "Vendor PN":
                    combo_box.addItems(self.get_existing_vendor_pns())
                layout.addRow(label, combo_box)
                self.input_fields[source_key] = combo_box
            else:
                line_edit = QLineEdit()
                layout.addRow(label, line_edit)
                self.input_fields[source_key] = line_edit

        self.input_fields["current_date"].setText(FUNCTION_MAPPING["current_date"]())
        self.input_fields["request_date"].setText(FUNCTION_MAPPING["request_date"]("14"))

    def finish_form(self):
        self.validate_and_confirm()
        if self.all_fields_filled():
            self.lock_fields()
            self.open_excel_button.setEnabled(True)
            self.send_email_button.setEnabled(True)
            self.finish_button.setText("解锁")
            self.finish_button.clicked.disconnect()
            self.finish_button.clicked.connect(self.unlock_fields)

    def all_fields_filled(self):
        for field in self.required_fields:
            input_field = self.input_fields.get(field)
            if isinstance(input_field, QLineEdit) and not input_field.text():
                return False
            elif isinstance(input_field, QComboBox) and not input_field.currentText():
                return False
        return True

    def lock_fields(self):
        for field in self.input_fields.values():
            field.setEnabled(False)

    def unlock_fields(self):
        for field in self.input_fields.values():
            field.setEnabled(True)
        self.open_excel_button.setEnabled(False)
        self.send_email_button.setEnabled(False)
        self.finish_button.setText("填写完成")
        self.finish_button.clicked.disconnect()
        self.finish_button.clicked.connect(self.finish_form)

    def open_excel(self):
        output_path = self.generate_form()
        self.open_file(output_path)

    def get_existing_model_names(self):
        """从数据库获取现有的 Model Name 列表"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT model_name FROM projects")
        model_names = [row[0] for row in cursor.fetchall()]
        conn.close()
        return model_names

    def get_existing_pns(self):
        """从数据库获取现有的 PN 列表"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT pn FROM components")
        pns = [row[0] for row in cursor.fetchall()]
        conn.close()
        return pns

    def get_existing_vendor_pns(self):
        """从数据库获取现有的 Vendor PN 列表"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT vendor_pn FROM components")
        vendor_pns = [row[0] for row in cursor.fetchall()]
        conn.close()
        return vendor_pns

    def load_template_config(self, template_name, section, key):
        """加载模板配置文件
        从 JSON 配置文件中加载指定模板的配置信息。

        参数:
        template_name (str): 模板名称。
        section (str): 配置部分（如 auto_load, required）。
        key (str): 配置键（如 fields, types）。

        返回:
        list: 配置信息列表。
        """
        config_path = "templates_config.json"
        if not os.path.exists(config_path):
            QMessageBox.critical(self, "错误", "配置文件不存在！")
            return []

        with open(config_path, 'r', encoding='utf-8') as file:
            config = json.load(file)

        return config.get(template_name, {}).get(section, {}).get(key, [])

    def load_data(self):
        """加载数据
        根据用户输入的 Model Name 或 PN，从数据库中加载项目和组件数据，并自动填充表单字段。
        """
        model_name = self.input_fields.get("model_name", None)
        pn = self.input_fields.get("pn", None)
        vendor_pn = self.input_fields.get("vendor_pn", None)

        model_name_text = model_name.currentText() if model_name else ""
        pn_text = pn.currentText() if pn else ""
        vendor_pn_text = vendor_pn.currentText() if vendor_pn else ""

        if not model_name_text and not pn_text and not vendor_pn_text:
            QMessageBox.warning(self, "警告", "请填写Model Name或PN或Vendor PN")
            return

        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()

        project_data = None
        component_data = None

        if model_name_text:
            cursor.execute("SELECT * FROM projects WHERE model_name=?", (model_name_text,))
            project_data = cursor.fetchone()

        if vendor_pn_text:
            cursor.execute("SELECT * FROM components WHERE vendor_pn=?", (vendor_pn_text,))
            component_data = cursor.fetchone()

        if not project_data and not component_data:
            QMessageBox.warning(self, "警告", "没有找到相关数据")
            return

        # 将元组转换为字典
        if project_data:
            project_data = dict(zip(FIELD_MAPPING["projects"].keys(), project_data))
        if component_data:
            component_data = dict(zip(FIELD_MAPPING["components"].keys(), component_data))

        self.fill_data(project_data, component_data)
        conn.close()

    def fill_data(self, project_data, component_data):
        """填充表单数据
        根据从数据库加载的项目和组件数据，自动填充表单字段。

        参数:
        project_data (dict): 项目数据。
        component_data (dict): 组件数据。
        """

        def set_field(field_name, value):
            field = self.input_fields.get(field_name)
            if field:
                if isinstance(field, QLineEdit):
                    field.setText(str(value))
                elif isinstance(field, QComboBox):
                    index = field.findText(str(value))
                    if index >= 0:
                        field.setCurrentIndex(index)
                    else:
                        field.setEditText(str(value))

        def get_source_value(source, project_data, component_data):
            """获取字段值
            根据 source 的类型从项目数据、组件数据或函数中获取对应的值。
            """
            source_type, *params = source.split(":")
            if params:
                field_name = params[0]
                if source_type == "project" and project_data:
                    return project_data.get(field_name, "")
                elif source_type == "component" and component_data:
                    return component_data.get(field_name, "")
                elif source_type == "function":
                    func = FUNCTION_MAPPING.get(field_name)
                    if func:
                        if len(params) > 1:
                            return func(*params[1:])
                        return func()
            return ""

        if project_data:
            for field_name in FIELD_MAPPING["projects"]:
                set_field(field_name, project_data[field_name])

        if component_data:
            for field_name in FIELD_MAPPING["components"]:
                set_field(field_name, component_data[field_name])

        all_fields = {**self.required_sources, **self.optional_sources}
        for field_name, source in all_fields.items():
            source_key = source.split(":")[1] if ":" in source else field_name
            value = get_source_value(source, project_data, component_data)
            set_field(source_key, value)

    def validate_and_confirm(self):
        """验证表单并显示确认界面"""
        missing_fields = []

        # 验证必填字段是否已填写
        for field in self.required_fields:
            input_field = self.input_fields.get(field)
            if isinstance(input_field, QLineEdit):
                if not input_field.text():
                    input_field.setStyleSheet("border: 1px solid red;")
                    missing_fields.append(field)
                else:
                    input_field.setStyleSheet("")  # 清除红色边框
            elif isinstance(input_field, QComboBox):
                if not input_field.currentText():
                    input_field.setStyleSheet("border: 1px solid red;")
                    missing_fields.append(field)
                else:
                    input_field.setStyleSheet("")  # 清除红色边框

        if missing_fields:
            QMessageBox.warning(self, "警告", f"请填写必填项：{', '.join(missing_fields)}")
            return

        # 显示确认界面
        confirmation = QMessageBox.question(self, "确认", "确认所有数据已填写完毕？",
                                            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if confirmation == QMessageBox.Yes:
            self.update_database()

    def update_database(self):
        """更新数据库"""
        conn = sqlite3.connect('form_data.db')
        cursor = conn.cursor()

        project_data = {}
        component_data = {}

        # 收集用户输入的数据
        for field in FIELD_MAPPING["projects"].keys():
            input_field = self.input_fields.get(field)
            if isinstance(input_field, QLineEdit):
                project_data[field] = input_field.text()
            elif isinstance(input_field, QComboBox):
                project_data[field] = input_field.currentText()

        for field in FIELD_MAPPING["components"].keys():
            input_field = self.input_fields.get(field)
            if isinstance(input_field, QLineEdit):
                component_data[field] = input_field.text()
            elif isinstance(input_field, QComboBox):
                component_data[field] = input_field.currentText()

        # 确保所有必填字段都存在于 component_data 中
        for field in FIELD_MAPPING["components"].keys():
            if field not in component_data:
                component_data[field] = ""

        # 检查并更新数据库
        model_name = project_data.get("model_name")
        cursor.execute("SELECT * FROM projects WHERE model_name=?", (model_name,))
        existing_project_tuple = cursor.fetchone()

        if not existing_project_tuple:
            # 新增项目数据
            cursor.execute('''
                INSERT INTO projects (model_name, bg, bu, forcast, end_customer, ee_name, product, location, mag_list, stage, rd_name, other_params)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                project_data.get('model_name'), project_data.get('bg'), project_data.get('bu'), project_data.get('forcast'),
                project_data.get('end_customer'), project_data.get('ee_name'), project_data.get('product'),
                project_data.get('location'), project_data.get('mag_list'), project_data.get('stage'),
                project_data.get('rd_name'), project_data.get('other_params')
            ))
        else:
            existing_project = tuple_to_dict(FIELD_MAPPING["projects"].keys(), existing_project_tuple)
            # 更新项目数据
            for key, value in project_data.items():
                if key in existing_project and value and value != existing_project[key]:
                    confirmation = QMessageBox.question(self, "确认更改",
                                                        f"项目字段 '{key}' 的值将从 '{existing_project[key]}' 更改为 '{value}'，是否确认？",
                                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if confirmation == QMessageBox.Yes:
                        cursor.execute(f"UPDATE projects SET {key}=? WHERE model_name=?", (value, model_name))

        # 处理组件数据（类似项目数据的处理逻辑）
        vendor_pn = component_data.get("vendor_pn")
        cursor.execute("SELECT * FROM components WHERE vendor_pn=?", (vendor_pn,))
        existing_component_tuple = cursor.fetchone()

        if not existing_component_tuple:
            # 提示用户是否新建组件数据
            create_new_component = QMessageBox.question(self, "新建组件",
                                                        f"组件 '{vendor_pn}' 不存在，是否新建？",
                                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if create_new_component == QMessageBox.Yes:
                cursor.execute('''
                    INSERT INTO components (vendor_pn, pn, revision, product, rd_name, drawn, supplier, core_type, delta_material, material_type, selection_orientation, material1, material2, material3, material4, material5, insulation_system, other_params)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    component_data.get('vendor_pn'), component_data.get('pn'), component_data.get('revision'),
                    component_data.get('product'), component_data.get('rd_name'), component_data.get('drawn'),
                    component_data.get('supplier'), component_data.get('core_type'), component_data.get('delta_material'),
                    component_data.get('material_type'), component_data.get('selection_orientation'), component_data.get('material1'),
                    component_data.get('material2'), component_data.get('material3'), component_data.get('material4'), component_data.get('material5'),
                    component_data.get('insulation_system'), component_data.get('other_params')
                ))
        else:
            existing_component = tuple_to_dict(FIELD_MAPPING["components"].keys(), existing_component_tuple)
            # 更新组件数据
            for key, value in component_data.items():
                if key in existing_component and value and value != existing_component[key]:
                    confirmation = QMessageBox.question(self, "确认更改",
                                                        f"组件字段 '{key}' 的值将从 '{existing_component[key]}' 更改为 '{value}'，是否确认？",
                                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                    if confirmation == QMessageBox.Yes:
                        cursor.execute(f"UPDATE components SET {key}=? WHERE vendor_pn=?", (value, vendor_pn))

        conn.commit()
        conn.close()

        QMessageBox.information(self, "提示", "数据已更新，并生成表单！")
        self.generate_form()

    def generate_form(self):
        """生成表单
        从模板读取数据并生成新的表单，填充用户输入的数据。
        """
        # 加载模板
        template_path = f"./templates/{self.template_name}"
        wb = openpyxl.load_workbook(template_path)
        ws = wb.active

        # 获取所有占位符并替换
        for row in ws.iter_rows():
            for cell in row:
                if cell.value and isinstance(cell.value, str) and "{" in cell.value and "}" in cell.value:
                    placeholder = cell.value
                    field_name = placeholder.strip("{}")
                    source_key = self.input_fields.get(field_name)
                    if source_key:
                        cell.value = source_key.text() if isinstance(source_key, QLineEdit) else source_key.currentText()

        # 确保输出文件夹存在
        output_folder = "./output"
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # 动态生成文件名
        core_type = self.input_fields.get("core_type").text()
        bu = self.input_fields.get("bu").text()
        apply_date = self.input_fields.get("current_date").text()  # 使用 current_date
        output_filename = f"{core_type}索樣申請單 FOR {bu}BU {apply_date}.xlsx"
        output_path = os.path.join(output_folder, output_filename)
        print(f"输出路径: {output_path}")  # 打印生成的文件路径以供检查

        # 保存新表单
        wb.save(output_path)

        # 显示对话框，包含打开和发送邮件按钮
        msg_box = QMessageBox(self)
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setText(f"表单已生成并保存在 {output_path}！")
        msg_box.setWindowTitle("提示")
        open_button = msg_box.addButton("打开", QMessageBox.ActionRole)
        email_button = msg_box.addButton("发送邮件", QMessageBox.ActionRole)
        msg_box.addButton(QMessageBox.Ok)
        msg_box.exec()

        if msg_box.clickedButton() == open_button:
            self.open_file(output_path)
        elif msg_box.clickedButton() == email_button:
            self.send_email(output_path, core_type, bu)

    def open_file(self, file_path):
        """打开生成的 Excel 文件"""
        os.startfile(file_path)

    def send_email(self, attachment_path, core_type, bu):
        """发送邮件并附加生成的 Excel 文件"""
        attachment_path = os.path.abspath(attachment_path)
        print(f"邮件附件路径: {attachment_path}")  # 打印路径以供检查

        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.Subject = f"{core_type}索樣申請 FOR {bu}BU"
        mail.Body = "请查看附件"
        mail.To = "ODIN.YT.HUANG@deltaww.com"  # 设置默认收件人
        mail.CC = "Rita.Wang@deltaww.com; Hong.ju@deltaww.com"
        mail.Attachments.Add(attachment_path)
        mail.Display(False)  # 显示邮件窗口，但不锁死表单填写窗口

if __name__ == "__main__":
    app = QApplication([])
    window = FormSelectionWindow()
    window.show()
    app.exec()
