import json
from PySide6.QtWidgets import QComboBox


def load_email_template(template_name):
    """加载指定模板的邮件配置信息"""
    with open('email_templates.json', 'r', encoding='utf-8') as file:
        templates = json.load(file)
    return templates.get(template_name, {})


def generate_email_body(template_name, input_fields, get_source_key):
    """生成邮件正文"""
    email_template = load_email_template(template_name)

    if template_name == "鐵芯索樣申請表(2024年).xlsx":
        parameters = [
            "BG", "BU", "Mag Design", "Pilot Run On", "Forcast(k/Mouth)",
            "Selection Orientation", "Material Type", "Supplier",
            "Delta Material", "Core Type", "Usage", "Apply Date",
            "Request Date", "Quantity Requested"
        ]

        parameters_table = """
        <style>
            body { font-family: 'Microsoft YaHei', Arial, sans-serif; }
            table { border-collapse: collapse; width: auto; margin: 0 auto; }
            th, td { border: 2px solid black; padding: 4px; }
            th { font-weight: bold; background-color: #d9d9d9; text-align: center; }
            td { text-align: center; }
        </style>
        <table>
            <tr><th>项目</th><th>参数</th></tr>"""

        for param in parameters:
            source_key = get_source_key(param)
            print(source_key)
            value = input_fields.get(source_key).currentText() if isinstance(input_fields.get(source_key),
                                                                             QComboBox) else input_fields.get(
                source_key).text()
            parameters_table += f"<tr><td style='text-align: left;'>{param}</td><td style='background-color: #FFFF00;'>{value}</td></tr>"
        parameters_table += "</table>"

        remark_key = get_source_key("Remarks")
        remark_value = input_fields.get(remark_key).text() if input_fields.get(remark_key) else ""

        if remark_value:
            remark_html = f"<p><strong><u>Remark: {remark_value}</u></strong></p>"
        else:
            remark_html = ""

        body_template = f"""
        <html>
        <head>
            <style>
                body {{ font-family: 'Microsoft YaHei', Arial, sans-serif; }}
            </style>
        </head>
        <body>
            <p>Dear {email_template.get("recipient_name", "")},</p>
            <p>請協助向廠商詢價與索樣，謝謝！</p>
            {remark_html}
            <p>資訊如下:</p>
            {parameters_table}
            <p>鐵心尺寸截圖如下:</p>
            <p></p>
            <p>Best Regards！</p>
        </body>
        </html>
        """
    else:
        body_template = """
        <html>
        <head>
            <style>
                body { font-family: 'Microsoft YaHei', Arial, sans-serif; }
            </style>
        </head>
        <body>
            <p>Dear {recipient_name},</p>
            <p>请查看附件</p>
        </body>
        </html>
        """
    return body_template
