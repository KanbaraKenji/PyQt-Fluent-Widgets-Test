import os
import pandas as pd
from openpyxl import load_workbook
import sqlite3

# 数据库初始化
def init_db():
    conn = sqlite3.connect('project_data.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            mag_list TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS mags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            model_name TEXT,
            mag_design TEXT,
            bg TEXT,
            bu TEXT,
            core_type TEXT,
            FOREIGN KEY(project_id) REFERENCES projects(id)
        )
    ''')
    conn.commit()
    conn.close()

# 加载表单模板
def load_templates(template_dir='templates'):
    templates = [f for f in os.listdir(template_dir) if f.endswith('.xlsx')]
    return templates

# 选择表单模板
def select_template(templates):
    print("表單列表:")
    for i, template in enumerate(templates, 1):
        print(f"{i}. {template}")
    choice = int(input("請選擇一個編單編號: ")) - 1
    return templates[choice]

# 填写表单信息
def fill_form(template):
    model_name = input("Enter Model Name: ")

    # 查找数据库记录
    conn = sqlite3.connect('project_data.db')
    c = conn.cursor()
    c.execute("SELECT * FROM mags WHERE model_name = ?", (model_name,))
    record = c.fetchone()
    if record:
        print("找到數據庫記錄，自動填充已知参数")
        _, project_id, model_name, mag_design, bg, bu, core_type = record
        data = {
            'Model Name': model_name,
            'Mag Design': mag_design,
            'BG': bg,
            'BU': bu,
            'Core Type': core_type
        }
    else:
        print("未找到數據庫記錄. 請手動填寫數據信息.")
        mag_design = input("Enter Mag Design: ")
        bg = input("Enter BG: ")
        bu = input("Enter BU: ")
        core_type = input("Enter Core Type: ")

        c.execute("INSERT INTO projects (name, mag_list) VALUES (?, ?)", (model_name, ""))
        project_id = c.lastrowid
        c.execute("INSERT INTO mags (project_id, model_name, mag_design, bg, bu, core_type) VALUES (?, ?, ?, ?, ?, ?)",
                  (project_id, model_name, mag_design, bg, bu, core_type))
        conn.commit()
        data = {
            'Model Name': model_name,
            'Mag Design': mag_design,
            'BG': bg,
            'BU': bu,
            'Core Type': core_type
        }
    conn.close()
    return data

# 确认数据
def confirm_data(data):
    print("請再次確認數據是否正確:")
    for key, value in data.items():
        print(f"{key}: {value}")
    confirmation = input("請確認以上數據是否正確? (yes/no): ").strip().lower()
    if confirmation == 'no':
        key_to_edit = input("請問選擇需要修改的數據選項? (e.g., Model Name): ").strip()
        if key_to_edit in data:
            new_value = input(f"請輸入更新參數 {key_to_edit}: ").strip()
            data[key_to_edit] = new_value
            data = confirm_data(data)  # Recursively confirm data again
    return data

# 更新数据库
def update_db(data):
    conn = sqlite3.connect('project_data.db')
    c = conn.cursor()
    c.execute("SELECT * FROM mags WHERE model_name = ?", (data['Model Name'],))
    record = c.fetchone()
    if record:
        _, project_id, model_name, mag_design, bg, bu, core_type = record
        changes = {}
        if data['Mag Design'] != mag_design:
            changes['Mag Design'] = data['Mag Design']
        if data['BG'] != bg:
            changes['BG'] = data['BG']
        if data['BU'] != bu:
            changes['BU'] = data['BU']
        if data['Core Type'] != core_type:
            changes['Core Type'] = data['Core Type']

        if changes:
            print("如下數據與數據庫已有數據有差異:")
            for key, value in changes.items():
                print(f"{key}: {value}")
            confirm_changes = input("請確認是否修改數據庫數據為新的數值? (yes/no): ").strip().lower()
            if confirm_changes == 'yes':
                for key, value in changes.items():
                    c.execute(f"UPDATE mags SET {key.lower().replace(' ', '_')} = ? WHERE model_name = ?", (value, data['Model Name']))
                conn.commit()
    conn.close()

# 输出表单到Excel
def output_to_excel(template, data, form_name, output_dir='output'):
    os.makedirs(output_dir, exist_ok=True)
    template_path = os.path.join('templates', template)
    workbook = load_workbook(template_path)
    sheet = workbook.active

    # 查找并替换占位符
    for row in sheet.iter_rows():
        for cell in row:
            if cell.value and isinstance(cell.value, str):
                for key, value in data.items():
                    cell.value = cell.value.replace(f'{{{key}}}', value)

    output_path = os.path.join(output_dir, f"{data['Model Name']}_{form_name}.xlsx")
    workbook.save(output_path)
    print(f"輸出表格 {output_path}")

def main():
    init_db()
    templates = load_templates()
    template = select_template(templates)
    data = fill_form(template)
    data = confirm_data(data)
    update_db(data)
    output_to_excel(template, data, template)

if __name__ == "__main__":
    main()
