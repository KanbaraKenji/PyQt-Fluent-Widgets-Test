from datetime import datetime, timedelta

# 项目字段映射
PROJECT_FIELDS = {
    "model_name": "model_name",
    "bg": "bg",
    "bu": "bu",
    "model_forcast": "model_forcast",
    "end_customer": "end_customer",
    "ee_name": "ee_name",
    "product": "product",
    "mag_list": "mag_list",
    "stage": "stage",
    "rd_name": "rd_name",
    "location": "location",
    "other_params": "other_params",
    "mp_date": "mp_date",
    "lifecycle": "lifecycle"
}

# 组件字段映射
COMPONENT_FIELDS = {
    "vendor_pn": "vendor_pn",
    "pn": "pn",
    "revision": "revision",
    "rd_name": "rd_name",
    "drawn": "drawn",
    "supplier": "supplier",
    "core_type": "core_type",
    "delta_material": "delta_material",
    "material_type": "material_type",
    "selection_orientation": "selection_orientation",
    "material1": "material1",
    "material2": "material2",
    "material3": "material3",
    "material4": "material4",
    "material5": "material5",
    "insulation_system": "insulation_system",
    "other_params": "other_params",
    "modify_from": "modify_from",
    "price": "price",
    "ref_core_pn": "ref_core_pn"
}

# 关联表字段映射
PROJECTS_COMPONENTS_FIELDS = {
    "project_model_name": "project_model_name",
    "component_vendor_pn": "component_vendor_pn",
    "mag_type": "mag_type",
    "location": "location",
    "mag_forcast": "mag_forcast"
}

# 字段映射
FIELD_MAPPING = {
    "projects": PROJECT_FIELDS,
    "components": COMPONENT_FIELDS,
    "projects_components": PROJECTS_COMPONENTS_FIELDS
}

# 函数映射
def current_date():
    """返回当前日期的字符串格式"""
    return datetime.now().strftime("%Y-%m-%d")

def request_date(days):
    """返回指定天数后的日期"""
    return (datetime.now() + timedelta(days=int(days))).strftime("%Y-%m-%d")

FUNCTION_MAPPING = {
    "current_date": current_date,
    "request_date": request_date,
}
