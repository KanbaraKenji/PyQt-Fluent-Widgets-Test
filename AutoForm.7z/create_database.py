import sqlite3

def create_database():
    conn = sqlite3.connect('form_data.db')
    cursor = conn.cursor()

    # 创建 projects 表，包含所有指定字段
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS projects (
        model_name TEXT PRIMARY KEY,
        bg TEXT,
        bu TEXT,
        model_forcast TEXT,
        end_customer TEXT,
        ee_name TEXT,
        product TEXT,
        mag_list TEXT,
        stage TEXT,
        rd_name TEXT,
        location TEXT,
        other_params TEXT,
        mp_date TEXT,
        lifecycle TEXT
    )
    ''')

    # 创建 components 表，包含所有指定字段
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS components (
        vendor_pn TEXT PRIMARY KEY,
        pn TEXT,
        revision TEXT,
        rd_name TEXT,
        drawn TEXT,
        supplier TEXT,
        core_type TEXT,
        delta_material TEXT,
        material_type TEXT,
        selection_orientation TEXT,
        material1 TEXT,
        material2 TEXT,
        material3 TEXT,
        material4 TEXT,
        material5 TEXT,
        insulation_system TEXT,
        other_params TEXT,
        modify_from TEXT,
        price REAL,
        ref_core_pn TEXT
    )
    ''')

    # 创建 projects_components 关联表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS projects_components (
        project_model_name TEXT,
        component_vendor_pn TEXT,
        mag_type TEXT,
        location TEXT,
        mag_forcast TEXT,
        PRIMARY KEY (project_model_name, component_vendor_pn),
        FOREIGN KEY (project_model_name) REFERENCES projects (model_name),
        FOREIGN KEY (component_vendor_pn) REFERENCES components (vendor_pn)
    )
    ''')

    # 添加示例数据
    cursor.execute('''
    INSERT OR REPLACE INTO projects 
    (model_name, bg, bu, model_forcast, end_customer, ee_name, product, mag_list, stage, rd_name, location, other_params, mp_date, lifecycle) 
    VALUES 
    ("ModelA", "BG_A", "BU_A", "1.5", "CustomerA", "EE_A", "ProductA", "MagListA", "StageA", "RD_A", "LocationA", "Other Params for ModelA", "2024-01-01", "In Production")
    ''')

    cursor.execute('''
    INSERT OR REPLACE INTO components 
    (vendor_pn, pn, revision, rd_name, drawn, supplier, core_type, delta_material, material_type, selection_orientation, material1, material2, material3, material4, material5, insulation_system, other_params, modify_from, price, ref_core_pn) 
    VALUES 
    ("VendorPN1", "PN1", "RevA", "RD_A", "Drawn_A", "Supplier_A", "CoreType_A", "Material1_A", "MaterialType_A", "Selection_A", "Material1_A", "Material2_A", "Material3_A", "Material4_A", "Material5_A", "Insulation_A", "Other Params for PN1", "ModifyFrom_A", 100.0, "N/A")
    ''')

    cursor.execute('''
    INSERT OR REPLACE INTO projects_components 
    (project_model_name, component_vendor_pn, mag_type, location, mag_forcast) 
    VALUES 
    ("ModelA", "VendorPN1", "MagTypeA", "LocationA", "50")
    ''')

    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_database()
