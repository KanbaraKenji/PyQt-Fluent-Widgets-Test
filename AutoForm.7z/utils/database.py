# utils/database.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from utils.models import Base, Project, Component, Material, ProjectComponent

# 创建引擎
engine = create_engine('sqlite:///form_data.db', echo=False)

# 创建会话工厂
Session = scoped_session(sessionmaker(bind=engine))


def initialize_database():
    """初始化数据库，创建所有表并应用迁移"""
    if not engine.dialect.has_table(engine, 'projects'):
        Base.metadata.create_all(engine)

    # 自动应用 Alembic 迁移
    from alembic.config import Config
    from alembic import command
    import os

    alembic_cfg_path = os.path.join(os.path.dirname(__file__), '../alembic.ini')
    alembic_cfg = Config(alembic_cfg_path)
    try:
        command.upgrade(alembic_cfg, "head")
    except Exception as e:
        print(f"应用 Alembic 迁移时出错: {e}")

    # 插入初始数据（如果需要）
    session = get_session()

    # 检查是否有示例项目
    if not session.query(Project).filter_by(model_name="ModelA").first():
        project = Project(
            model_name="ModelA",
            bg="BG_A",
            bu="BU_A",
            model_forcast=1.5,
            end_customer="CustomerA",
            ee_name="EE_A",
            product="ProductA",
            mag_list="MagListA",
            stage="StageA",
            rd_name="RD_A",
            location="LocationA",
            other_params="Other Params for ModelA",
            mp_date="2024-01-01",
            lifecycle="In Production"
        )
        session.add(project)

    # 检查是否有示例组件
    if not session.query(Component).filter_by(vendor_pn="VendorPN1").first():
        component = Component(
            vendor_pn="VendorPN1",
            pn="PN1",
            revision="RevA",
            rd_name="RD_A",
            drawn="Drawn_A",
            supplier="Supplier_A",
            core_type="CoreType_A",
            delta_material="Material1_A",
            material_type="MaterialType_A",
            selection_orientation="Selection_A",
            insulation_system="Insulation_A",
            other_params="Other Params for PN1",
            modify_from="ModifyFrom_A",
            price=100.0,
            ref_core_pn="N/A"
        )
        session.add(component)

    # 检查是否有示例关联
    if not session.query(ProjectComponent).filter_by(project_model_name="ModelA",
                                                     component_vendor_pn="VendorPN1").first():
        project_component = ProjectComponent(
            project_model_name="ModelA",
            component_vendor_pn="VendorPN1",
            mag_type="MagTypeA",
            location="LocationA",
            mag_forcast=50.0
        )
        session.add(project_component)

    session.commit()


def get_session():
    """获取数据库会话"""
    return Session()


def add_project(session, project_data):
    """添加或更新项目"""
    project = session.query(Project).filter_by(model_name=project_data['model_name']).first()
    if project:
        for key, value in project_data.items():
            setattr(project, key, value)
    else:
        project = Project(**project_data)
        session.add(project)
    session.commit()


def get_project_by_name(session, model_name):
    """通过 model_name 查询项目"""
    return session.query(Project).filter_by(model_name=model_name).first()


def add_component(session, component_data):
    """添加或更新组件"""
    component = session.query(Component).filter_by(vendor_pn=component_data['vendor_pn']).first()
    if component:
        for key, value in component_data.items():
            setattr(component, key, value)
    else:
        component = Component(**component_data)
        session.add(component)
    session.commit()


def get_component_by_vendor_pn(session, vendor_pn):
    """通过 vendor_pn 查询组件"""
    return session.query(Component).filter_by(vendor_pn=vendor_pn).first()


def add_project_component(session, project_model_name, component_vendor_pn, mag_type, location, mag_forcast):
    """添加或更新项目与组件的关联"""
    project_component = session.query(ProjectComponent).filter_by(
        project_model_name=project_model_name,
        component_vendor_pn=component_vendor_pn
    ).first()

    if project_component:
        project_component.mag_type = mag_type
        project_component.location = location
        project_component.mag_forcast = mag_forcast
    else:
        project_component = ProjectComponent(
            project_model_name=project_model_name,
            component_vendor_pn=component_vendor_pn,
            mag_type=mag_type,
            location=location,
            mag_forcast=mag_forcast
        )
        session.add(project_component)
    session.commit()


def get_all_model_names(session):
    """获取所有项目的模型名称"""
    return [project.model_name for project in session.query(Project).all()]


def get_all_vendor_pns(session):
    """获取所有组件的 vendor_pn"""
    return [component.vendor_pn for component in session.query(Component).all()]

